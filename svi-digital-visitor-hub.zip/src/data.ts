import { FactoryTourStep, CertificationItem, Visit } from "./types";
// @ts-ignore
import smtLineImg from "./assets/images/smt_line_custom_1784175800551.jpg";

export const FACTORY_TOUR_STEPS: FactoryTourStep[] = [
  {
    id: "step-1",
    title: "Receiving & Incoming",
    subtitle: "Material Integrity & Component Control",
    explanation: "SVI's material control protocol is designed for total counterfeit avoidance in line with AS5553 standards. Every component undergoes strict incoming inspection, real-time barcoding, and automated counting. Parts are routed to our specialized humidity-controlled storage (Class MSD-3) and Nitrogen cabinets to protect structural electronic integrity from humidity and ESD hazards.",
    image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=1200",
    metrics: [
      { label: "Traceability & Barcoding", value: "100% GS1 Compliant" },
      { label: "Climate-Controlled Storage", value: "MSD-3 & N2 Cabinet System" },
      { label: "Anti-Counterfeit Standard", value: "AS5553 Certified" }
    ],
    iconName: "FileCheck",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-electronic-components-on-a-table-41551-large.mp4"
  },
  {
    id: "step-2",
    title: "SMT Lines & Automated Assembly",
    subtitle: "45 Advanced High-Volume SMT Lines",
    explanation: "SVI operates 45 fully equipped SMT lines globally (Thailand: 26, Cambodia: 10, USA: 4, Slovakia: 2, Austria: 3) utilizing advanced FUJI and SAMSUNG chip placement machinery. Engineered to handle ultra-high complexity, fine-pitch layouts. Features inline Solder Paste Inspection (SPI) and automated dual-lane operation for maximum throughput and reliability, with convection reflow (12-zone in Asia, 10-zone in Europe).",
    image: smtLineImg,
    metrics: [
      { label: "Global SMT Footprint", value: "45 Lines (TH: 26, KH: 10, US: 4, SK: 2, AT: 3)" },
      { label: "Convection Reflow Ovens", value: "12-Zone (Asia) / 10-Zone (Europe)" },
      { label: "Placement Machine Fleet", value: "FUJI & SAMSUNG High-Speed" },
      { label: "SMT Capability Limits", value: "Thickness 0.4mm // Warpage 0.1mm" }
    ],
    iconName: "Cpu",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-hands-of-a-technician-soldering-a-chip-43516-large.mp4"
  },
  {
    id: "step-3",
    title: "Automated Inspection (SPI & AOI)",
    subtitle: "3D Solder Quality & Precision Control",
    explanation: "Our high-precision manufacturing is backed by fully integrated 3D SPI (Solder Paste Inspection) and inline 3D AOI (Automatic Optical Inspection) machines seamlessly tied to the SMT lines. We utilize high-grade silver alloy for superior solder joints and low-active (No clean) flux, with custom-engineered laser-cut Nano-coated stainless steel stencils.",
    image: "https://images.unsplash.com/photo-1563770660941-20978e870e26?auto=format&fit=crop&q=80&w=1200",
    metrics: [
      { label: "SPI / AOI Integration", value: "100% Inline 3D Inspection" },
      { label: "Mounting Accuracy", value: "+/- 0.025 mm" },
      { label: "Max Speed Capacity", value: "Up to 92,000 CPH" },
      { label: "Stencil Coating Profile", value: "Nano-Coated Laser-Cut" }
    ],
    iconName: "Eye",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-motherboard-of-a-computer-with-circuit-lines-close-up-41549-large.mp4"
  },
  {
    id: "step-4",
    title: "Chip-on-Board & Cleanroom Assembly",
    subtitle: "High-Density Bare-Die Integration",
    explanation: "SVI's Chip-on-Board (COB) technology mounts bare ICs directly onto the printed circuit board, maximizing space efficiency for advanced MedTech, aerospace, and high-frequency communication electronics. Features Dual-Metallurgy Wire Bonding utilizing high-durability Aluminum (Al) and Gold (Au) bonding. All operations are conducted in certified ISO Class 7 (10K) and ISO Class 8 (100K) cleanroom environments.",
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=1200",
    metrics: [
      { label: "Controlled Environment", value: "ISO Class 7 (10K) & Class 8 (100K)" },
      { label: "Wire Bonding Pitch", value: "18 Microns Capability" },
      { label: "Bonding Metallurgy", value: "Aluminum (Al) & Gold (Au)" },
      { label: "Placement Precision", value: "30 Microns Wire Precision" }
    ],
    iconName: "Layers",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-close-up-of-hands-assembling-electronic-components-41553-large.mp4"
  },
  {
    id: "step-5",
    title: "Reliability & Failure Analysis Labs",
    subtitle: "Advanced Component-Level Diagnostics",
    explanation: "Our state-of-the-art Reliability Test Laboratory and Failure Analysis Laboratory validate product durability under real-world conditions. Equipped with 3D CT X-ray inspection (6 μm/pixel), High/Low temperature testing machines with thermal cycle chambers (-40°C to 150°C), programmable salt spray testing, and Chemical-decapsulation tools to ensure flawless component-level integrity.",
    image: "https://images.unsplash.com/photo-1601524909162-be87252be298?auto=format&fit=crop&q=80&w=1200",
    metrics: [
      { label: "X-Ray Diagnostics", value: "3D CT X-Ray System (6μm/pixel)" },
      { label: "Thermal Lab Range", value: "-40°C to 150°C Cycle Ovens" },
      { label: "Salt Spray Corrosion", value: "+RT~50°C, 95%~98% RH" },
      { label: "FA Lab Decapsulation", value: "Chemical Fume & Ultrasonic" }
    ],
    iconName: "Activity",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-assembly-line-of-electronic-boards-41555-large.mp4"
  },
  {
    id: "step-6",
    title: "System Integration & Box Build",
    subtitle: "Aerospace, Medical, and Automotive Products",
    explanation: "SVI provides complex, turnkey system-level box builds, integrating precision plastic enclosures, wire harnesses, display assemblies, and mechanical structures. Our processes are governed by world-class standards including ISO 13485 (Medical), AS9100 (Aerospace), and IATF 16949 (Automotive) to support rigorous, mission-critical applications.",
    image: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=1200",
    metrics: [
      { label: "Compliance Standards", value: "ISO 13485, AS9100, IATF 16949" },
      { label: "Workmanship Standard", value: "IPC-A-610 / IPC-A-600 Class 3" },
      { label: "Torque Calibration", value: "Electronic Closed-Loop Control" },
      { label: "Environmental Protection", value: "IP67 / IP68 Enclosure Seals" }
    ],
    iconName: "ShieldCheck",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-modern-factory-robotic-arm-working-41550-large.mp4"
  },
  {
    id: "step-7",
    title: "Quality Check & Sustainable Packing",
    subtitle: "Greenhouse Gas Compliance & ESG Packing",
    explanation: "Finished devices undergo final inspection under IPC 7711/7721 certified rework standards before being packaged. To support our net-zero targets and comply with ISO 14001 & ISO 14064-1 greenhouse gas auditing, we use 100% recyclable, bio-based packing materials and custom anti-static (ESD) shielding bags to guarantee safe global logistics.",
    image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?auto=format&fit=crop&q=80&w=1200",
    metrics: [
      { label: "ESD Envelope Protection", value: "< 10 nJ Energy Penetration" },
      { label: "Carbon Neutrality Align", value: "ISO 14064-1 Greenhouse Gas" },
      { label: "Eco Manufacturing Cert", value: "ISO 14001 Environmental" }
    ],
    iconName: "Truck",
    videoUrl: "https://assets.mixkit.co/videos/preview/mixkit-man-working-with-packaging-boxes-in-warehouse-42861-large.mp4"
  }
];

export const CERTIFICATIONS: CertificationItem[] = [
  {
    id: "cert-1",
    code: "ISO 13485:2016",
    title: "Medical Device Quality Management System",
    description: "Specifies requirements for a quality management system where an organization needs to demonstrate its ability to provide medical devices and related services that consistently meet customer and applicable regulatory requirements.",
    industry: "Medical Electronics"
  },
  {
    id: "cert-2",
    code: "AS9100",
    title: "Aerospace Quality Management System",
    description: "The international quality management system standard for the Aviation, Space, and Defense industry. Assures structural integrity, component safety, and strict flight-critical electronic compliance.",
    industry: "Aerospace Electronics"
  },
  {
    id: "cert-3",
    code: "IATF 16949:2016",
    title: "Automotive Quality Management System",
    description: "Defines the quality management system requirements for automotive production and relevant service part organizations, focusing on defect prevention and reducing supply chain variation.",
    industry: "Automotive Electronics"
  },
  {
    id: "cert-4",
    code: "ISO/IEC 27001",
    title: "Information Security Management System",
    description: "The international standard for managing information security, ensuring robust data protection, intellectual property security, and cyber resilience across all SVI manufacturing sites.",
    industry: "Information Security"
  },
  {
    id: "cert-5",
    code: "ISO 9001:2015",
    title: "Quality Management System",
    description: "The global foundation for product and service quality. Demonstrates SVI's capacity to consistently exceed customer expectations through standardized continuous improvement processes.",
    industry: "General Manufacturing"
  },
  {
    id: "cert-6",
    code: "ISO 14001:2015",
    title: "Environmental Management System",
    description: "Specifies requirements for an environmental management system, helping SVI reduce waste, optimize resource efficiency, and meet international green manufacturing compliance standards.",
    industry: "Sustainability & ESG"
  },
  {
    id: "cert-7",
    code: "ISO 14064-1:2018",
    title: "Greenhouse Gases Inventory",
    description: "Provides principles and requirements for quantification and reporting of greenhouse gas (GHG) emissions and removals, reinforcing SVI's alignment with international net-zero targets.",
    industry: "Sustainability & ESG"
  },
  {
    id: "cert-8",
    code: "ISO 45001:2018",
    title: "Occupational Health & Safety Management System",
    description: "Establishes a framework to improve employee safety, reduce workplace risks, and create healthier, safer working environments for SVI operators globally.",
    industry: "Sustainability & ESG"
  },
  {
    id: "cert-9",
    code: "AS5553",
    title: "Counterfeit Electronic Parts Avoidance",
    description: "Standardizes practices and requirements for the avoidance, detection, mitigation, and disposition of counterfeit electronic parts in the SVI components procurement pipeline.",
    industry: "Component Integrity"
  },
  {
    id: "cert-10",
    code: "IPC 7711/7721",
    title: "Rework, Modification and Repair of Electronic Assemblies",
    description: "The industry standard for procedures and guidelines on the quality rework, modification, and physical repair of printed circuit boards and electronic assemblies.",
    industry: "General Manufacturing"
  }
];

export const DEFAULT_VISITS: Visit[] = [
  {
    id: "demovisit",
    customerName: "Acme Corporation",
    customerLogo: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=200",
    visitDate: "2026-07-16",
    meetingRoom: "Boardroom Alpha (SVI HQ, 2nd Floor)",
    wifiUser: "SVI_Visitor_Guest",
    wifiPassword: "AcmeVisit2026!",
    lunchMenu: [
      "Signature Thai Crab Fried Rice",
      "Traditional Pad Thai (Vegetarian Option)",
      "Premium Kurobuta Pork Ribs",
      "Organic Butterfly Pea Lemongrass Infused Water"
    ],
    hostTeam: [
      "Kitti Dr. Somchai (President of Operations)",
      "Nattaporn S. (VP of Quality Assurance)",
      "Patchara K. (Lead Account Director)"
    ],
    visitorList: [
      { id: "v-1", name: "Sarah Jenkins", title: "VP of Global Hardware Procurement" },
      { id: "v-2", name: "Marcus Chen", title: "Principal Quality Architect" },
      { id: "v-3", name: "Elena Rostov", title: "Lead Supply Chain Strategist" }
    ],
    agenda: [
      {
        id: "a-1",
        time: "09:00 - 09:30",
        title: "Registration & Welcome Refreshments",
        description: "Arrival at SVI Reception, badge issue, and opening tea/coffee in Boardroom Alpha."
      },
      {
        id: "a-2",
        time: "09:30 - 10:15",
        title: "Corporate Briefing & Capabilities Overview",
        description: "Presentation of SVI's global EMS footprint, design capabilities, and commercial milestones."
      },
      {
        id: "a-3",
        time: "10:15 - 11:30",
        title: "Guided factory Tour & Line Audits",
        description: "On-site walk through SMT assembly lines, 3D AOI inspection stations, and our automotive-certified cleanrooms."
      },
      {
        id: "a-4",
        time: "11:30 - 13:00",
        title: "Executive Networking Lunch",
        description: "A selection of fine local and international cuisines. Casual Q&A with the SVI engineering directors."
      },
      {
        id: "a-5",
        time: "13:00 - 15:00",
        title: "Technical Collaboration & Quality Session",
        description: "Deep dive into component sourcing strategies, product testing parameters, and compliance schedules."
      },
      {
        id: "a-6",
        time: "15:00 - 15:30",
        title: "Wrap-up & Action Item Summary",
        description: "Agreement on commercial next steps, documentation sharing, and visitor check-out."
      }
    ],
    documents: [
      { id: "d-1", title: "SVI Corporate Capabilities Overview.pdf", size: "4.8 MB", type: "PDF", url: "#" },
      { id: "d-2", title: "SVI ESG Carbon-Neutrality Report.pdf", size: "2.3 MB", type: "PDF", url: "#" },
      { id: "d-3", title: "ISO 13485 & IATF 16949 Certificate Pack.zip", size: "12.1 MB", type: "ZIP", url: "#" }
    ],
    notes: "Special dietary request: Marcus Chen has a shellfish allergy. Kitchen notified to prepare alternative non-seafood Pad Thai.",
    emergencyContact: {
      name: "SVI Helpdesk & Security Admin",
      role: "Guest Coordination Lead",
      phone: "+66 (0) 2 105 0456 Ext. 888"
    }
  },
  {
    id: "apple",
    customerName: "Apple Inc.",
    customerLogo: "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?auto=format&fit=crop&q=80&w=200",
    visitDate: "2026-07-20",
    meetingRoom: "Conference Center Executive Suite",
    wifiUser: "SVI_Apple_Audit",
    wifiPassword: "SecureSMTLine1",
    lunchMenu: [
      "Pan-Seared Sea Bass with Lemon Caper Sauce",
      "Sous-Vide Ribeye Steak with Roasted Asparagus",
      "Artisanal Goat Cheese Beetroot Salad",
      "SVI Cold-Brew Espresso Selection"
    ],
    hostTeam: [
      "Arisara M. (Lead Account Principal)",
      "Pravit N. (SMT Engineering Fellow)",
      "Chaiwat J. (EHS Director)"
    ],
    visitorList: [
      { id: "v-4", name: "David Miller", title: "Hardware Engineering Director" },
      { id: "v-5", name: "Tiffany Wang", title: "Global Supply Manager" }
    ],
    agenda: [
      {
        id: "ap-1",
        time: "08:30 - 09:00",
        title: "Reception & Security Clearance",
        description: "Non-Disclosure Agreement (NDA) checks and smart glass badge issuance."
      },
      {
        id: "ap-2",
        time: "09:00 - 10:30",
        title: "Strategic Roadmap Review",
        description: "Confidential hardware blueprints discussion and joint technology alignment."
      },
      {
        id: "ap-3",
        time: "10:30 - 12:30",
        title: "Strict Cleanroom Audit (NPI Line)",
        description: "Comprehensive walkthrough of our micro-electronics cleanroom, ESD monitors, and Nitrogen cabinets."
      },
      {
        id: "ap-4",
        time: "12:30 - 13:30",
        title: "Catered Executive Lunch",
        description: "Private lunch inside the Executive Pavilion."
      },
      {
        id: "ap-5",
        time: "13:30 - 15:30",
        title: "DFM (Design for Manufacturing) Workshop",
        description: "SVI engineering team feedback on board layer stacking and heat-dissipation layouts."
      }
    ],
    documents: [
      { id: "d-4", title: "SVI NPI Engineering Process Guide.pdf", size: "6.1 MB", type: "PDF", url: "#" },
      { id: "d-5", title: "ESD Protection Best Practices Handbook.pdf", size: "1.9 MB", type: "PDF", url: "#" }
    ],
    emergencyContact: {
      name: "Security Desk Command Room",
      role: "EHS Officer",
      phone: "+66 (0) 2 105 0456 Ext. 101"
    }
  }
];
