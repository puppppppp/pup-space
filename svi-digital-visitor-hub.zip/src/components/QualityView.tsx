import React, { useState } from "react";
import { CERTIFICATIONS } from "../data";
import { ShieldCheck, FileText, Download, Check, Filter } from "lucide-react";

export default function QualityView() {
  const [activeTab, setActiveTab] = useState("All");

  const categories = ["All", "General Manufacturing", "Medical Electronics", "Automotive Electronics", "Aerospace Electronics", "Information Security", "Component Integrity", "Sustainability & ESG"];

  const filteredCertifications = activeTab === "All"
    ? CERTIFICATIONS
    : CERTIFICATIONS.filter((cert) => cert.industry === activeTab);

  return (
    <div className="space-y-10 py-4 animate-fade-in">
      {/* Title block */}
      <div className="border-b border-slate-100 pb-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-sans font-bold text-slate-900 tracking-tight">Quality & Certifications</h1>
          <p className="text-slate-500 text-sm font-light mt-1">
            Browse our validated list of international quality standards, medical manufacturing controls, and automotive audit stamps.
          </p>
        </div>
        <button
          id="download-all-certs"
          className="flex items-center space-x-1.5 px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white font-semibold text-sm rounded-xl transition-all shadow-md shrink-0"
        >
          <Download className="w-4 h-4" />
          <span>Download Certificates Pack</span>
        </button>
      </div>

      {/* SVI Quality Assurance Banner */}
      <section className="bg-gradient-to-tr from-indigo-950 to-slate-900 rounded-3xl p-6 md:p-10 text-white shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 rounded-full bg-emerald-500/10 blur-3xl" />
        <div className="relative z-10 max-w-3xl space-y-3">
          <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wide">
            Zero-Defect Quality Strategy
          </span>
          <h2 className="text-2xl md:text-3xl font-sans font-bold leading-tight">
            Our Quality Philosophy: Operational Excellence
          </h2>
          <p className="text-slate-300 text-sm md:text-base font-light leading-relaxed">
            SVI implements rigorous continuous improvement cycles across all global sites. From incoming solder-paste inspection to thermal burn-in stress cabinets, our procedures conform to stringent medical and high-reliability aerospace standards, guaranteeing continuous operational compliance.
          </p>
          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 pt-3 text-xs font-mono text-slate-400">
            <span className="flex items-center space-x-1">
              <Check className="w-4.5 h-4.5 text-emerald-400" />
              <span>100% Traceability (SMT)</span>
            </span>
            <span className="flex items-center space-x-1">
              <Check className="w-4.5 h-4.5 text-emerald-400" />
              <span>Lead-Free Reflow Certified</span>
            </span>
            <span className="flex items-center space-x-1">
              <Check className="w-4.5 h-4.5 text-emerald-400" />
              <span>IPC-A-610 Class II & III standards</span>
            </span>
          </div>
        </div>
      </section>

      {/* Filter Tabs */}
      <div className="flex items-center space-x-2 pb-2 overflow-x-auto scrollbar-thin">
        <span className="text-xs font-mono text-slate-400 flex items-center space-x-1 mr-2 shrink-0">
          <Filter className="w-3.5 h-3.5" />
          <span>Filter Focus:</span>
        </span>
        {categories.map((cat) => (
          <button
            key={cat}
            id={`filter-cert-${cat.replace(/\s+/g, "-")}`}
            onClick={() => setActiveTab(cat)}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all shrink-0 border ${
              activeTab === cat
                ? "bg-slate-900 border-slate-900 text-white"
                : "bg-white border-slate-200 text-slate-600 hover:text-slate-900 hover:border-slate-300"
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid: Certificate Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCertifications.map((cert) => (
          <div
            key={cert.id}
            className="group bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm hover:shadow-md hover:border-slate-300 transition-all duration-300 flex flex-col justify-between min-h-[250px]"
          >
            <div>
              {/* Card Header */}
              <div className="flex items-center justify-between mb-4">
                <span className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-lg text-xs font-mono font-bold border border-indigo-100">
                  {cert.code}
                </span>
                <ShieldCheck className="w-5 h-5 text-emerald-500" />
              </div>

              {/* Title & Industry */}
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide block">
                {cert.industry}
              </span>
              <h3 className="text-base font-sans font-bold text-slate-900 mt-0.5 group-hover:text-indigo-600 transition-colors">
                {cert.title}
              </h3>

              {/* Description */}
              <p className="text-sm text-slate-500 font-light mt-2.5 leading-relaxed">
                {cert.description}
              </p>
            </div>

            {/* Bottom Download link */}
            <div className="pt-4 border-t border-slate-100 mt-6 flex justify-between items-center text-xs font-semibold text-slate-700 group-hover:text-indigo-600 cursor-pointer">
              <span className="flex items-center space-x-1">
                <FileText className="w-4 h-4 shrink-0 text-slate-400 group-hover:text-indigo-400" />
                <span>Certificate PDF</span>
              </span>
              <Download className="w-4 h-4 text-slate-400 group-hover:text-indigo-500 transition-transform group-hover:translate-y-0.5" />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
