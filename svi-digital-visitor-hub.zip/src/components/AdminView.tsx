import React, { useState } from "react";
import { Visit, AgendaItem, Visitor, DocumentLink } from "../types";
import {
  Plus,
  Trash2,
  Save,
  Copy,
  Check,
  ExternalLink,
  Edit2,
  Briefcase,
  FileText,
  Wifi,
  Calendar,
  Layers,
  Sparkles,
  RefreshCw,
  QrCode,
  Users,
  Utensils,
  MapPin,
  Clock,
  ArrowRight,
  Upload
} from "lucide-react";

interface AdminViewProps {
  visits: Visit[];
  onSaveVisit: (visit: Visit) => void;
  onDeleteVisit: (id: string) => void;
  onSetActiveVisit: (id: string) => void;
  activeVisitId: string;
}

export default function AdminView({
  visits,
  onSaveVisit,
  onDeleteVisit,
  onSetActiveVisit,
  activeVisitId,
}: AdminViewProps) {
  // Navigation tabs within Admin Panel
  const [adminTab, setAdminTab] = useState<"list" | "form">("list");
  const [editingVisitId, setEditingVisitId] = useState<string | null>(null);

  // Form State
  const [customerName, setCustomerName] = useState("");
  const [customerLogo, setCustomerLogo] = useState("");
  const [visitDate, setVisitDate] = useState("");
  const [meetingRoom, setMeetingRoom] = useState("");
  const [wifiUser, setWifiUser] = useState("");
  const [wifiPassword, setWifiPassword] = useState("");
  const [notes, setNotes] = useState("");
  const [emergencyName, setEmergencyName] = useState("");
  const [emergencyRole, setEmergencyRole] = useState("");
  const [emergencyPhone, setEmergencyPhone] = useState("");

  // Array Lists inside Form
  const [visitorList, setVisitorList] = useState<Visitor[]>([]);
  const [agenda, setAgenda] = useState<AgendaItem[]>([]);
  const [lunchMenu, setLunchMenu] = useState<string[]>([]);
  const [hostTeam, setHostTeam] = useState<string[]>([]);
  const [documents, setDocuments] = useState<DocumentLink[]>([]);

  // Input states for adding new rows
  const [newVisitorName, setNewVisitorName] = useState("");
  const [newVisitorTitle, setNewVisitorTitle] = useState("");

  const [newAgendaTime, setNewAgendaTime] = useState("");
  const [newAgendaTitle, setNewAgendaTitle] = useState("");
  const [newAgendaDesc, setNewAgendaDesc] = useState("");

  const [newLunchDish, setNewLunchDish] = useState("");
  const [newHostStaff, setNewHostStaff] = useState("");

  const [newDocTitle, setNewDocTitle] = useState("");
  const [newDocSize, setNewDocSize] = useState("");
  const [newDocType, setNewDocType] = useState("PDF");
  const [newDocUrl, setNewDocUrl] = useState("#");
  const [isDocDragging, setIsDocDragging] = useState(false);

  const handleFileUpload = (file: File) => {
    if (file.size > 2 * 1024 * 1024) {
      alert("File size exceeds 2 MB. Please select a smaller file (Max 2MB) to ensure stable storage.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const base64Data = reader.result as string;
      const sizeMB = file.size / (1024 * 1024);
      const sizeStr = sizeMB >= 0.1 ? `${sizeMB.toFixed(2)} MB` : `${(file.size / 1024).toFixed(0)} KB`;
      const ext = file.name.split(".").pop()?.toUpperCase() || "PDF";
      setNewDocTitle(file.name);
      setNewDocSize(sizeStr);
      if (["PDF", "ZIP", "DOCX"].includes(ext)) {
        setNewDocType(ext);
      } else {
        setNewDocType("PDF");
      }
      setNewDocUrl(base64Data);
    };
    reader.readAsDataURL(file);
  };

  // Share Dialog / Saved Modal State
  const [savedVisitId, setSavedVisitId] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // Load an existing visit to edit
  const handleEditVisit = (visit: Visit) => {
    setEditingVisitId(visit.id);
    setCustomerName(visit.customerName);
    setCustomerLogo(visit.customerLogo);
    setVisitDate(visit.visitDate);
    setMeetingRoom(visit.meetingRoom);
    setWifiUser(visit.wifiUser);
    setWifiPassword(visit.wifiPassword || "");
    setNotes(visit.notes || "");
    setEmergencyName(visit.emergencyContact?.name || "");
    setEmergencyRole(visit.emergencyContact?.role || "");
    setEmergencyPhone(visit.emergencyContact?.phone || "");

    setVisitorList([...visit.visitorList]);
    setAgenda([...visit.agenda]);
    setLunchMenu([...visit.lunchMenu]);
    setHostTeam([...visit.hostTeam]);
    setDocuments([...visit.documents]);

    setAdminTab("form");
  };

  // Launch fresh form
  const handleCreateNew = () => {
    setEditingVisitId(null);
    setCustomerName("");
    setCustomerLogo("");
    setVisitDate(new Date().toISOString().split("T")[0]);
    setMeetingRoom("Boardroom Alpha (SVI HQ, 2nd Floor)");
    setWifiUser("SVI_Visitor_Guest");
    setWifiPassword("SVI" + Math.floor(1000 + Math.random() * 9000) + "!");
    setNotes("");
    setEmergencyName("SVI Liaison & Guest Relations");
    setEmergencyRole("Operations Lead");
    setEmergencyPhone("+66 (0) 2 105 0456 Ext. 888");

    setVisitorList([]);
    setAgenda([
      { id: "a1", time: "09:00 - 09:30", title: "Registration & Welcome", description: "Arrival at SVI Headquarters, badge issue, and opening refreshments." },
      { id: "a2", time: "09:30 - 10:15", title: "Capabilities Overview", description: "SVI global EMS services and strategic business presentations." },
      { id: "a3", time: "10:15 - 11:30", title: "Guided Factory SMT Tour", description: "Walkthrough of high-speed placement lines, inspection bays, and automotive audits." },
      { id: "a4", time: "11:30 - 13:00", title: "Executive Lunch", description: "Gourmet dining at SVI Private Lounge." },
      { id: "a5", time: "13:00 - 15:00", title: "Technical Collaboration Workshop", description: "Strategic discussions regarding product schedules and component supply chain." }
    ]);
    setLunchMenu(["Signature Thai Crab Rice", "Organic Lemongrass Tea", "Fresh Mango Sticky Rice"]);
    setHostTeam(["Kitti Somchai (Executive VP)", "Nattaporn S. (Lead Quality Auditor)"]);
    setDocuments([
      { id: "d1", title: "SVI Company Brochure.pdf", size: "3.2 MB", type: "PDF", url: "#" },
      { id: "d2", title: "SVI Environmental ESG Summary.pdf", size: "1.9 MB", type: "PDF", url: "#" }
    ]);

    setAdminTab("form");
  };

  // List Management Add Handlers
  const addVisitor = () => {
    if (newVisitorName.trim()) {
      const newVisitor: Visitor = {
        id: "v-" + Date.now(),
        name: newVisitorName.trim(),
        title: newVisitorTitle.trim() || "Visitor Representative"
      };
      setVisitorList([...visitorList, newVisitor]);
      setNewVisitorName("");
      setNewVisitorTitle("");
    }
  };

  const removeVisitor = (id: string) => {
    setVisitorList(visitorList.filter((v) => v.id !== id));
  };

  const addAgendaItem = () => {
    if (newAgendaTime.trim() && newAgendaTitle.trim()) {
      const newItem: AgendaItem = {
        id: "a-" + Date.now(),
        time: newAgendaTime.trim(),
        title: newAgendaTitle.trim(),
        description: newAgendaDesc.trim() || "Brief session detailing custom project workflows."
      };
      setAgenda([...agenda, newItem]);
      setNewAgendaTime("");
      setNewAgendaTitle("");
      setNewAgendaDesc("");
    }
  };

  const removeAgendaItem = (id: string) => {
    setAgenda(agenda.filter((item) => item.id !== id));
  };

  const addLunchDish = () => {
    if (newLunchDish.trim()) {
      setLunchMenu([...lunchMenu, newLunchDish.trim()]);
      setNewLunchDish("");
    }
  };

  const removeLunchDish = (idx: number) => {
    setLunchMenu(lunchMenu.filter((_, i) => i !== idx));
  };

  const addHostStaff = () => {
    if (newHostStaff.trim()) {
      setHostTeam([...hostTeam, newHostStaff.trim()]);
      setNewHostStaff("");
    }
  };

  const removeHostStaff = (idx: number) => {
    setHostTeam(hostTeam.filter((_, i) => i !== idx));
  };

  const addDoc = () => {
    if (newDocTitle.trim()) {
      const newDocument: DocumentLink = {
        id: "doc-" + Date.now(),
        title: newDocTitle.trim(),
        size: newDocSize.trim() || "1.2 MB",
        type: newDocType,
        url: newDocUrl || "#"
      };
      setDocuments([...documents, newDocument]);
      setNewDocTitle("");
      setNewDocSize("");
      setNewDocType("PDF");
      setNewDocUrl("#");
    }
  };

  const removeDoc = (id: string) => {
    setDocuments(documents.filter((d) => d.id !== id));
  };

  // Compile and Save Visit Handler
  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim()) return;

    const newId = editingVisitId || customerName.toLowerCase().replace(/[^a-z0-9]/g, "") || "visit-" + Math.floor(100 + Math.random() * 900);
    
    // Default logo URL if empty
    const resolvedLogo = customerLogo.trim() || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=200";

    const compiledVisit: Visit = {
      id: newId,
      customerName: customerName.trim(),
      customerLogo: resolvedLogo,
      visitDate: visitDate || new Date().toISOString().split("T")[0],
      meetingRoom: meetingRoom.trim() || "Boardroom Alpha",
      wifiUser: wifiUser.trim() || "SVI_Guest",
      wifiPassword: wifiPassword.trim(),
      lunchMenu: lunchMenu.length > 0 ? lunchMenu : ["Executive Catering"],
      hostTeam: hostTeam.length > 0 ? hostTeam : ["SVI Representative Desk"],
      visitorList: visitorList.length > 0 ? visitorList : [{ id: "v-def", name: "Guest Delegate", title: "Hardware Procurement" }],
      agenda: agenda.length > 0 ? agenda : [{ id: "a-def", time: "09:30 - 10:30", title: "Capabilities & Line Audit", description: "Review of SVI's industrial line configurations." }],
      documents: documents.length > 0 ? documents : [{ id: "d-def", title: "SVI Profile Summary.pdf", size: "2.4 MB", type: "PDF", url: "#" }],
      notes: notes.trim() || undefined,
      emergencyContact: {
        name: emergencyName.trim() || "SVI Helpdesk",
        role: emergencyRole.trim() || "Liaison Coordination Team",
        phone: emergencyPhone.trim() || "+66 (0) 2 105 0456"
      }
    };

    onSaveVisit(compiledVisit);
    setSavedVisitId(newId);
    setEditingVisitId(null);
  };

  const getShareUrl = (visitId: string) => {
    // Generate the clean Visit URL format requested: visit.svi.com/visit/abc123
    // Under static client environments, we resolve to the actual app hash route which parses instantly!
    const origin = window.location.origin + window.location.pathname;
    return `${origin}#/visit/${visitId}`;
  };

  const handleCopyLink = (url: string) => {
    navigator.clipboard.writeText(url);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="space-y-10 py-4 animate-fade-in relative">
      {/* Title section */}
      <div className="border-b border-slate-100 pb-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-sans font-bold text-slate-900 tracking-tight flex items-center space-x-2.5">
            <Sparkles className="w-7 h-7 text-indigo-600" />
            <span>SVI Corporate Portal Admin</span>
          </h1>
          <p className="text-slate-500 text-sm font-light mt-1">
            Build, edit, and launch premium digital visitor schedules without writing a single line of code.
          </p>
        </div>

        {adminTab === "list" && (
          <button
            id="admin-create-new-btn"
            onClick={handleCreateNew}
            className="flex items-center space-x-2 px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-xl transition-all shadow-md shrink-0"
          >
            <Plus className="w-4.5 h-4.5" />
            <span>Create New Visit</span>
          </button>
        )}
      </div>

      {/* SVI Database Saved Confirmation Overlay (Modal) */}
      {savedVisitId && (
        <div className="fixed inset-0 bg-slate-950/40 backdrop-blur-md z-50 flex items-center justify-center p-4">
          <div className="bg-white border border-slate-200 shadow-2xl rounded-3xl p-6 md:p-8 max-w-lg w-full animate-scale-up space-y-6">
            <div className="text-center space-y-2">
              <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 mb-2">
                <Check className="w-6 h-6 font-bold" />
              </div>
              <h3 className="text-2xl font-sans font-extrabold text-slate-900">
                Visitor Hub Generated!
              </h3>
              <p className="text-sm text-slate-500 font-light max-w-sm mx-auto">
                No-code compilation completed. The private, responsive hub is now ready to share.
              </p>
            </div>

            {/* Generated clean URL display */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-1 text-center">
              <span className="text-[10px] font-mono text-slate-400 uppercase font-bold tracking-wide block">
                SVI Custom Shareable Address
              </span>
              <span className="text-xs font-mono font-bold text-indigo-700 block select-all break-all">
                {getShareUrl(savedVisitId)}
              </span>
            </div>

            {/* QR Code and SVI Scan Desk design */}
            <div className="flex flex-col items-center p-4 border border-indigo-50 rounded-2xl bg-indigo-50/20 space-y-3">
              <span className="text-xs font-mono font-bold text-slate-400">RECEPTION BOARD QR CODE</span>
              
              {/* Premium Vector High-Tech QR Code SVG simulator */}
              <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-inner">
                <svg className="w-32 h-32 text-slate-900" viewBox="0 0 100 100">
                  <path fill="currentColor" d="M0,0 h30 v10 h-20 v20 h-10 Z M70,0 h30 v30 h-10 v-20 h-20 Z M0,70 h10 v20 h20 v10 h-30 Z M90,70 v20 h-20 v10 h30 v-30 Z" />
                  {/* Outer corner positioning squares */}
                  <rect x="10" y="10" width="20" height="20" fill="currentColor" />
                  <rect x="13" y="13" width="14" height="14" fill="white" />
                  <rect x="16" y="16" width="8" height="8" fill="currentColor" />

                  <rect x="70" y="10" width="20" height="20" fill="currentColor" />
                  <rect x="73" y="13" width="14" height="14" fill="white" />
                  <rect x="76" y="16" width="8" height="8" fill="currentColor" />

                  <rect x="10" y="70" width="20" height="20" fill="currentColor" />
                  <rect x="13" y="73" width="14" height="14" fill="white" />
                  <rect x="16" y="76" width="8" height="8" fill="currentColor" />

                  {/* High tech pixelated dots */}
                  <rect x="40" y="15" width="4" height="4" fill="currentColor" />
                  <rect x="50" y="10" width="6" height="6" fill="currentColor" />
                  <rect x="45" y="25" width="8" height="4" fill="currentColor" />
                  <rect x="40" y="40" width="20" height="20" fill="currentColor" />
                  <rect x="45" y="45" width="10" height="10" fill="white" />
                  <rect x="48" y="48" width="4" height="4" fill="currentColor" />
                  
                  <rect x="15" y="45" width="6" height="6" fill="currentColor" />
                  <rect x="25" y="55" width="4" height="8" fill="currentColor" />
                  <rect x="70" y="45" width="8" height="4" fill="currentColor" />
                  <rect x="80" y="55" width="6" height="6" fill="currentColor" />
                  
                  <rect x="75" y="75" width="10" height="10" fill="currentColor" />
                  <rect x="80" y="80" width="4" height="4" fill="white" />
                </svg>
              </div>
              <span className="text-[10px] text-slate-500 font-sans text-center leading-relaxed">
                Scan this code at SVI Lobby Front Desk to instantly launch the Digital Hub on phone or tablet.
              </span>
            </div>

            {/* Link Interactions */}
            <div className="grid grid-cols-2 gap-4">
              <button
                id="modal-copy-link"
                onClick={() => handleCopyLink(getShareUrl(savedVisitId))}
                className={`py-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1.5 border ${
                  copiedLink
                    ? "bg-emerald-500 border-emerald-500 text-white"
                    : "bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200"
                }`}
              >
                {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copiedLink ? "Link Copied!" : "Copy Hub Link"}</span>
              </button>

              <button
                id="modal-open-link"
                onClick={() => {
                  window.location.hash = `/visit/${savedVisitId}`;
                  onSetActiveVisit(savedVisitId);
                  setSavedVisitId(null);
                  setAdminTab("list");
                }}
                className="py-3 rounded-xl text-xs font-bold bg-indigo-600 hover:bg-indigo-700 text-white transition-all flex items-center justify-center space-x-1.5 shadow-md shadow-indigo-600/10"
              >
                <span>Launch Hub</span>
                <ExternalLink className="w-4 h-4" />
              </button>
            </div>

            <button
              id="modal-close-btn"
              onClick={() => {
                setSavedVisitId(null);
                setAdminTab("list");
              }}
              className="w-full text-slate-400 hover:text-slate-600 text-xs text-center font-medium block pt-1 hover:underline"
            >
              Back to Corporate List
            </button>
          </div>
        </div>
      )}

      {/* Main Layout Area */}
      {adminTab === "list" ? (
        /* Visit List Dashboard */
        <section className="space-y-6">
          <div className="bg-white border border-slate-200/80 rounded-2xl shadow-sm overflow-hidden">
            <div className="p-5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h3 className="font-sans font-bold text-slate-900 text-base">Active Customer Registers</h3>
              <span className="px-2.5 py-0.5 bg-indigo-50 border border-indigo-100 text-indigo-700 rounded-full font-mono font-bold text-xs">
                {visits.length} Registered Visits
              </span>
            </div>

            <div className="divide-y divide-slate-100">
              {visits.map((v) => {
                const isCurrentlyActive = activeVisitId === v.id;
                return (
                  <div
                    key={v.id}
                    id={`admin-visit-row-${v.id}`}
                    className={`p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 hover:bg-slate-50/50 transition-all ${
                      isCurrentlyActive ? "bg-indigo-50/10" : ""
                    }`}
                  >
                    <div className="flex items-center space-x-4 min-w-0">
                      {/* Logo or Image */}
                      <img
                        src={v.customerLogo}
                        alt={v.customerName}
                        className="w-12 h-12 rounded-xl object-cover border border-slate-200"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0">
                        <div className="flex items-center space-x-2">
                          <span className="font-sans font-bold text-slate-900 truncate text-base">
                            {v.customerName}
                          </span>
                          {isCurrentlyActive && (
                            <span className="px-2 py-0.5 rounded-full text-[9px] font-extrabold font-mono uppercase bg-emerald-500 text-white">
                              Live Preview
                            </span>
                          )}
                        </div>
                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400 mt-1 font-mono">
                          <span className="flex items-center space-x-1">
                            <Calendar className="w-3.5 h-3.5 text-indigo-500" />
                            <span>{v.visitDate}</span>
                          </span>
                          <span className="flex items-center space-x-1">
                            <MapPin className="w-3.5 h-3.5 text-emerald-500" />
                            <span>{v.meetingRoom.split("(")[0]}</span>
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Operational Action Row */}
                    <div className="flex flex-wrap items-center gap-3 w-full md:w-auto self-stretch md:self-center justify-end">
                      <button
                        id={`btn-set-preview-${v.id}`}
                        onClick={() => {
                          onSetActiveVisit(v.id);
                        }}
                        className={`px-3.5 py-2 rounded-lg text-xs font-bold transition-all border ${
                          isCurrentlyActive
                            ? "bg-slate-900 border-slate-900 text-white"
                            : "bg-white hover:bg-slate-50 text-slate-700 border-slate-200"
                        }`}
                      >
                        {isCurrentlyActive ? "Active Preview" : "Set Active"}
                      </button>

                      <button
                        id={`btn-edit-visit-${v.id}`}
                        onClick={() => handleEditVisit(v)}
                        className="p-2 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-lg border border-slate-200 transition-all"
                        title="Edit Visit Config"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>

                      <button
                        id={`btn-copy-url-${v.id}`}
                        onClick={() => handleCopyLink(getShareUrl(v.id))}
                        className="p-2 bg-slate-50 hover:bg-slate-100 text-indigo-600 rounded-lg border border-slate-200 transition-all"
                        title="Copy Shareable Link"
                      >
                        <Copy className="w-4 h-4" />
                      </button>

                      {visits.length > 1 && (
                        <button
                          id={`btn-delete-visit-${v.id}`}
                          onClick={() => onDeleteVisit(v.id)}
                          className="p-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-lg border border-red-100 transition-all"
                          title="Delete Visit record"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Prompt banner to create */}
          <div className="bg-slate-900 rounded-2xl p-6 text-white flex flex-col md:flex-row md:items-center justify-between gap-6 shadow-md">
            <div>
              <h4 className="font-sans font-bold text-lg">Add a private Client Hub in seconds</h4>
              <p className="text-slate-300 text-sm font-light mt-1 max-w-xl">
                Ready to compile a schedule for another guest? Press the builder to pre-load corporate configurations for simple customization.
              </p>
            </div>
            <button
              id="admin-footer-create-btn"
              onClick={handleCreateNew}
              className="px-5 py-3 rounded-xl bg-white hover:bg-slate-100 text-slate-950 font-bold text-sm shrink-0 transition-all flex items-center space-x-1.5"
            >
              <span>Launch Builder</span>
              <ArrowRight className="w-4.5 h-4.5" />
            </button>
          </div>
        </section>
      ) : (
        /* Dynamic Creator / Editor Form */
        <form onSubmit={handleSave} className="space-y-8 max-w-5xl">
          {/* Form Header Action Bar */}
          <div className="flex items-center justify-between bg-slate-100 p-4 rounded-xl border border-slate-200/80">
            <span className="text-sm font-sans font-bold text-slate-700">
              {editingVisitId ? `Editing Profile: ${customerName}` : "New Visitor Profile Workspace"}
            </span>
            <div className="flex items-center space-x-2">
              <button
                type="button"
                id="form-cancel-btn"
                onClick={() => setAdminTab("list")}
                className="px-4 py-2 border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 rounded-lg text-xs font-semibold transition-all"
              >
                Discard Changes
              </button>
              <button
                type="submit"
                id="form-submit-btn"
                className="flex items-center space-x-1.5 px-4.5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all shadow-md"
              >
                <Save className="w-4 h-4" />
                <span>Save & Generate Hub</span>
              </button>
            </div>
          </div>

          {/* Form Content - Sectioned Panels */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* PANEL 1: GENERAL VISIT INFO */}
            <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
              <h3 className="text-sm font-mono font-bold text-indigo-600 uppercase tracking-wide border-b border-slate-100 pb-2">
                1. General Customer & Visit Info
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5 col-span-2 sm:col-span-1">
                  <label className="text-xs font-bold text-slate-700 font-sans block">Customer / Company Name:</label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder="e.g. Acme Corporation"
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 text-slate-800 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-medium"
                  />
                </div>

                <div className="space-y-1.5 col-span-2 sm:col-span-1">
                  <label className="text-xs font-bold text-slate-700 font-sans block">Visit Date:</label>
                  <input
                    type="date"
                    required
                    value={visitDate}
                    onChange={(e) => setVisitDate(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 text-slate-800 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-mono font-bold"
                  />
                </div>

                <div className="space-y-1.5 col-span-2">
                  <label className="text-xs font-bold text-slate-700 font-sans block">Customer Brand Logo URL:</label>
                  <input
                    type="url"
                    value={customerLogo}
                    onChange={(e) => setCustomerLogo(e.target.value)}
                    placeholder="https://images.unsplash.com/photo-..."
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 text-slate-800 text-xs focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
                  />
                  <span className="text-[10px] text-slate-400 block font-light">Leave empty to use our curated industrial vector placeholder.</span>
                </div>

                <div className="space-y-1.5 col-span-2">
                  <label className="text-xs font-bold text-slate-700 font-sans block">Boardroom / Meeting Room Location:</label>
                  <input
                    type="text"
                    required
                    value={meetingRoom}
                    onChange={(e) => setMeetingRoom(e.target.value)}
                    placeholder="e.g. Boardroom Alpha (SVI HQ, 2nd Floor)"
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 text-slate-800 text-sm focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all font-medium"
                  />
                </div>
              </div>
            </div>

            {/* PANEL 2: WI-FI & DINING */}
            <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
              <h3 className="text-sm font-mono font-bold text-indigo-600 uppercase tracking-wide border-b border-slate-100 pb-2">
                2. Guest Wi-Fi & Lunch Menu
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5 col-span-1">
                  <label className="text-xs font-bold text-slate-700 block">Wi-Fi Username:</label>
                  <input
                    type="text"
                    required
                    value={wifiUser}
                    onChange={(e) => setWifiUser(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 text-slate-800 text-xs font-mono focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1.5 col-span-1">
                  <label className="text-xs font-bold text-slate-700 block">Wi-Fi Password:</label>
                  <input
                    type="text"
                    required
                    value={wifiPassword}
                    onChange={(e) => setWifiPassword(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 text-slate-800 text-xs font-mono focus:border-indigo-500"
                  />
                </div>
              </div>

              {/* Dynamic Lunch Menu List Creator */}
              <div className="space-y-2.5 pt-2">
                <label className="text-xs font-bold text-slate-700 block">Lunch Menu Catering Selection:</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newLunchDish}
                    onChange={(e) => setNewLunchDish(e.target.value)}
                    placeholder="e.g. Signature Pad Thai (Mild)"
                    className="flex-1 px-3.5 py-2 rounded-lg border border-slate-200 text-xs focus:border-indigo-500"
                  />
                  <button
                    type="button"
                    onClick={addLunchDish}
                    className="px-3.5 bg-indigo-50 border border-indigo-200 text-indigo-600 rounded-lg text-xs font-semibold hover:bg-indigo-100 transition-all flex items-center space-x-1"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add</span>
                  </button>
                </div>

                {lunchMenu.length > 0 ? (
                  <div className="flex flex-wrap gap-2.5 pt-1">
                    {lunchMenu.map((dish, i) => (
                      <span
                        key={i}
                        className="inline-flex items-center space-x-1 px-2.5 py-1 rounded bg-slate-100 text-slate-700 text-xs font-medium border border-slate-200"
                      >
                        <span className="truncate max-w-[200px]">{dish}</span>
                        <button
                          type="button"
                          onClick={() => removeLunchDish(i)}
                          className="text-slate-400 hover:text-red-500 font-bold shrink-0 ml-1"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                ) : (
                  <span className="text-[11px] text-slate-400 italic block">No lunch dishes listed yet.</span>
                )}
              </div>
            </div>

            {/* PANEL 3: VISITOR DELEGATION & HOSTS */}
            <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
              <h3 className="text-sm font-mono font-bold text-indigo-600 uppercase tracking-wide border-b border-slate-100 pb-2">
                3. Visitor Delegation & SVI Hosts
              </h3>

              {/* Visitors Adder */}
              <div className="space-y-2.5">
                <label className="text-xs font-bold text-slate-700 block">Add Guest Delegates:</label>
                <div className="grid grid-cols-2 gap-2">
                  <input
                    type="text"
                    value={newVisitorName}
                    onChange={(e) => setNewVisitorName(e.target.value)}
                    placeholder="Delegate Full Name"
                    className="px-3 py-2 rounded-lg border border-slate-200 text-xs"
                  />
                  <input
                    type="text"
                    value={newVisitorTitle}
                    onChange={(e) => setNewVisitorTitle(e.target.value)}
                    placeholder="Title (e.g. Procurement Lead)"
                    className="px-3 py-2 rounded-lg border border-slate-200 text-xs"
                  />
                </div>
                <button
                  type="button"
                  onClick={addVisitor}
                  className="w-full py-2 bg-slate-50 border border-slate-200 text-slate-700 rounded-lg text-xs font-semibold hover:bg-slate-100 transition-all flex items-center justify-center space-x-1"
                >
                  <Plus className="w-4 h-4 text-slate-500" />
                  <span>Register Visitor Representative</span>
                </button>

                {visitorList.length > 0 ? (
                  <div className="divide-y divide-slate-100 border border-slate-150 rounded-lg max-h-[140px] overflow-y-auto">
                    {visitorList.map((visitor) => (
                      <div key={visitor.id} className="p-2 flex items-center justify-between text-xs hover:bg-slate-50">
                        <div className="min-w-0">
                          <span className="font-semibold text-slate-800 block truncate">{visitor.name}</span>
                          <span className="text-slate-400 block text-[10px] truncate">{visitor.title}</span>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeVisitor(visitor.id)}
                          className="text-slate-400 hover:text-red-500 p-1 shrink-0"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <span className="text-[11px] text-slate-400 italic block">No visitors registered.</span>
                )}
              </div>

              {/* Host Team Adder */}
              <div className="space-y-2.5 pt-2 border-t border-slate-100">
                <label className="text-xs font-bold text-slate-700 block">SVI Host Team Members:</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={newHostStaff}
                    onChange={(e) => setNewHostStaff(e.target.value)}
                    placeholder="e.g. Patchara K. (Lead Director)"
                    className="flex-1 px-3 py-2 rounded-lg border border-slate-200 text-xs"
                  />
                  <button
                    type="button"
                    onClick={addHostStaff}
                    className="px-3 bg-indigo-50 border border-indigo-200 text-indigo-600 rounded-lg text-xs font-semibold hover:bg-indigo-100 transition-all flex items-center space-x-1"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add</span>
                  </button>
                </div>

                {hostTeam.length > 0 ? (
                  <div className="flex flex-wrap gap-2 pt-1">
                    {hostTeam.map((staff, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center space-x-1 px-2.5 py-1 rounded bg-indigo-50/50 text-indigo-800 text-xs font-medium border border-indigo-100/50"
                      >
                        <span className="truncate max-w-[150px]">{staff}</span>
                        <button
                          type="button"
                          onClick={() => removeHostStaff(idx)}
                          className="text-indigo-400 hover:text-red-500 font-bold shrink-0 ml-1"
                        >
                          ×
                        </button>
                      </span>
                    ))}
                  </div>
                ) : (
                  <span className="text-[11px] text-slate-400 italic block">No SVI hosts assigned.</span>
                )}
              </div>
            </div>

            {/* PANEL 4: INTERACTIVE VISIT TIMELINE / AGENDA */}
            <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4 lg:row-span-2">
              <h3 className="text-sm font-mono font-bold text-indigo-600 uppercase tracking-wide border-b border-slate-100 pb-2">
                4. Today's Agenda (Timeline Planner)
              </h3>

              {/* Agenda Slot Adder */}
              <div className="p-3.5 rounded-xl border border-dashed border-slate-200 space-y-3 bg-slate-50/50">
                <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                  <div className="sm:col-span-4">
                    <input
                      type="text"
                      value={newAgendaTime}
                      onChange={(e) => setNewAgendaTime(e.target.value)}
                      placeholder="e.g. 09:30 - 10:15"
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs font-mono font-bold"
                    />
                  </div>
                  <div className="sm:col-span-8">
                    <input
                      type="text"
                      value={newAgendaTitle}
                      onChange={(e) => setNewAgendaTitle(e.target.value)}
                      placeholder="Agenda Session Title"
                      className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs font-sans font-bold"
                    />
                  </div>
                </div>

                <textarea
                  value={newAgendaDesc}
                  onChange={(e) => setNewAgendaDesc(e.target.value)}
                  placeholder="Short explanation detailing room location, speakers, or audit metrics..."
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs"
                  rows={2}
                />

                <button
                  type="button"
                  onClick={addAgendaItem}
                  className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition-all flex items-center justify-center space-x-1 shadow-md"
                >
                  <Plus className="w-4 h-4" />
                  <span>Insert Agenda Session</span>
                </button>
              </div>

              {/* Active Agenda Timeline Rows */}
              <div className="space-y-2.5">
                <label className="text-xs font-bold text-slate-700 block">Agenda Preview:</label>
                {agenda.length > 0 ? (
                  <div className="space-y-2 max-h-[350px] overflow-y-auto pr-1">
                    {agenda.map((item, index) => (
                      <div
                        key={item.id}
                        className="p-3.5 rounded-xl border border-slate-200 bg-white hover:border-slate-300 transition-all flex justify-between items-start text-xs group"
                      >
                        <div className="space-y-1.5 min-w-0 pr-2">
                          <div className="flex items-center space-x-2">
                            <span className="font-mono font-extrabold text-indigo-600 bg-indigo-50 px-1.5 py-0.5 rounded text-[10px]">
                              {item.time}
                            </span>
                            <span className="font-bold text-slate-800 truncate">{item.title}</span>
                          </div>
                          <p className="text-slate-400 font-light line-clamp-2 leading-relaxed">{item.description}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => removeAgendaItem(item.id)}
                          className="text-slate-300 hover:text-red-500 p-1 shrink-0 mt-0.5"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <span className="text-[11px] text-slate-400 italic block">No sessions planned. Minimum 1 session required.</span>
                )}
              </div>
            </div>

            {/* PANEL 5: ATTACHMENTS & EMERGENCY */}
            <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
              <h3 className="text-sm font-mono font-bold text-indigo-600 uppercase tracking-wide border-b border-slate-100 pb-2">
                5. Related Documents & Emergency
              </h3>

              {/* Documents Adder */}
              <div className="space-y-3.5">
                <label className="text-xs font-bold text-slate-700 block">Upload Attachments / Links:</label>
                
                {/* Visual Drag & Drop Upload Zone */}
                <div
                  onDragOver={(e) => {
                    e.preventDefault();
                    setIsDocDragging(true);
                  }}
                  onDragLeave={() => setIsDocDragging(false)}
                  onDrop={(e) => {
                    e.preventDefault();
                    setIsDocDragging(false);
                    const file = e.dataTransfer.files?.[0];
                    if (file) {
                      handleFileUpload(file);
                    }
                  }}
                  onClick={() => {
                    document.getElementById("admin-doc-upload-input")?.click();
                  }}
                  className={`border-2 border-dashed rounded-xl p-5 text-center transition-all cursor-pointer ${
                    isDocDragging
                      ? "border-indigo-500 bg-indigo-50/40 ring-2 ring-indigo-500/10"
                      : "border-slate-200 hover:border-indigo-300 hover:bg-slate-50/50"
                  }`}
                >
                  <input
                    id="admin-doc-upload-input"
                    type="file"
                    accept=".pdf,.zip,.docx"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) {
                        handleFileUpload(file);
                      }
                    }}
                  />
                  <div className="flex flex-col items-center justify-center space-y-2">
                    <div className="p-2 bg-indigo-50 rounded-lg text-indigo-600">
                      <Upload className="w-5 h-5" />
                    </div>
                    <div className="text-xs text-slate-700 font-sans">
                      <span className="font-semibold text-indigo-600 hover:underline">Click to upload file</span> or drag and drop here
                    </div>
                    <div className="text-[10px] text-slate-400 font-mono uppercase">
                      Supports PDF, ZIP, DOCX // Max 2 MB
                    </div>
                  </div>
                </div>

                {/* Manual Metadata Inputs / Auto-filled Display */}
                <div className="space-y-1.5 p-3 bg-slate-50 border border-slate-150 rounded-xl">
                  <span className="text-[9px] font-mono text-slate-400 font-bold uppercase tracking-wider block mb-1">
                    Document Profile (Auto-filled or Custom)
                  </span>
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-2">
                    <div className="sm:col-span-7">
                      <input
                        type="text"
                        value={newDocTitle}
                        onChange={(e) => setNewDocTitle(e.target.value)}
                        placeholder="File Name or Document Title"
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs bg-white text-slate-800"
                      />
                    </div>
                    <div className="sm:col-span-3">
                      <input
                        type="text"
                        value={newDocSize}
                        onChange={(e) => setNewDocSize(e.target.value)}
                        placeholder="Size (e.g. 1.5 MB)"
                        className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs font-mono bg-white text-slate-800"
                      />
                    </div>
                    <div className="sm:col-span-2">
                      <select
                        value={newDocType}
                        onChange={(e) => setNewDocType(e.target.value)}
                        className="w-full px-2 py-2 rounded-lg border border-slate-200 text-xs bg-white text-slate-800"
                      >
                        <option value="PDF">PDF</option>
                        <option value="ZIP">ZIP</option>
                        <option value="DOCX">DOCX</option>
                      </select>
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={addDoc}
                  disabled={!newDocTitle.trim()}
                  className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center space-x-1 border ${
                    newDocTitle.trim()
                      ? "bg-indigo-600 hover:bg-indigo-700 text-white border-indigo-700 shadow-sm shadow-indigo-600/10 cursor-pointer"
                      : "bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed"
                  }`}
                >
                  <Plus className="w-4 h-4" />
                  <span>Attach Document to SVI Profile</span>
                </button>

                {documents.length > 0 ? (
                  <div className="divide-y divide-slate-100 border border-slate-150 rounded-lg max-h-[140px] overflow-y-auto">
                    {documents.map((d) => (
                      <div key={d.id} className="p-2.5 flex items-center justify-between text-xs hover:bg-slate-50">
                        <div className="flex items-center space-x-2 min-w-0">
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-bold font-mono bg-red-100 text-red-700">
                            {d.type}
                          </span>
                          <span className="font-semibold text-slate-800 truncate block">{d.title}</span>
                        </div>
                        <div className="flex items-center space-x-2 shrink-0">
                          <span className="text-slate-400 text-[10px] font-mono">{d.size}</span>
                          <button
                            type="button"
                            onClick={() => removeDoc(d.id)}
                            className="text-slate-300 hover:text-red-500 p-1"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <span className="text-[11px] text-slate-400 italic block">No documents attached.</span>
                )}
              </div>

              {/* Emergency Contact */}
              <div className="space-y-3.5 pt-3 border-t border-slate-100">
                <label className="text-xs font-bold text-slate-700 block">SVI Emergency Coordination Liaison:</label>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                  <input
                    type="text"
                    required
                    value={emergencyName}
                    onChange={(e) => setEmergencyName(e.target.value)}
                    placeholder="Liaison Name"
                    className="px-3 py-2 rounded-lg border border-slate-200 text-xs font-sans font-medium"
                  />
                  <input
                    type="text"
                    required
                    value={emergencyRole}
                    onChange={(e) => setEmergencyRole(e.target.value)}
                    placeholder="Liaison Role"
                    className="px-3 py-2 rounded-lg border border-slate-200 text-xs font-sans"
                  />
                  <input
                    type="text"
                    required
                    value={emergencyPhone}
                    onChange={(e) => setEmergencyPhone(e.target.value)}
                    placeholder="Liaison Phone"
                    className="px-3 py-2 rounded-lg border border-slate-200 text-xs font-mono font-medium"
                  />
                </div>
              </div>

              {/* Dietary Notes */}
              <div className="space-y-1.5 pt-2">
                <label className="text-xs font-bold text-slate-700 block">Host notes & Special Dietary Instructions:</label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Sarah Jenkins is allergic to peanuts. Kitchen notified to adjust executive lunch menu."
                  className="w-full px-3.5 py-2.5 rounded-lg border border-slate-200 text-xs text-slate-700"
                  rows={2}
                />
              </div>
            </div>
          </div>
        </form>
      )}
    </div>
  );
}
