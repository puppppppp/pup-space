import React from "react";
import {
  Calendar,
  Building2,
  Layers,
  ShieldCheck,
  Wifi,
  MapPin,
  Users,
  Utensils,
  ArrowRight,
  Download,
  AlertCircle
} from "lucide-react";
import { Visit } from "../types";

interface HomeViewProps {
  visit: Visit;
  onNavigate: (view: string) => void;
}

export default function HomeView({ visit, onNavigate }: HomeViewProps) {
  // Simple greeting based on local time
  const getGreeting = () => {
    const hours = new Date().getHours();
    if (hours < 12) return "Good Morning";
    if (hours < 17) return "Good Afternoon";
    return "Welcome";
  };

  // Format date elegantly
  const formatDate = (dateStr: string) => {
    try {
      const options: Intl.DateTimeFormatOptions = {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
      };
      return new Date(dateStr).toLocaleDateString("en-US", options);
    } catch (e) {
      return dateStr;
    }
  };

  const navCards = [
    {
      id: "agenda",
      title: "Today's Agenda",
      description: "Step-by-step interactive schedule of today's presentations, audits, and sessions.",
      color: "from-blue-500 to-indigo-600",
      icon: Calendar,
      badge: `${visit.agenda?.length || 0} Sessions`,
    },
    {
      id: "overview",
      title: "Company Overview",
      description: "Discover SVI's world-class EMS capabilities, manufacturing facilities, and corporate footprint.",
      color: "from-emerald-500 to-teal-600",
      icon: Building2,
      badge: "SVI Profile",
    },
    {
      id: "tour",
      title: "Factory Tour Protocol",
      description: "Explore our interactive manufacturing roadmap from materials receiving to final box build.",
      color: "from-amber-500 to-orange-600",
      icon: Layers,
      badge: "7 Stages",
    },
    {
      id: "quality",
      title: "Quality & Certifications",
      description: "Review our certified global standards: ISO 9001, ISO 13485 (Medical), and IATF 16949 (Automotive).",
      color: "from-violet-500 to-fuchsia-600",
      icon: ShieldCheck,
      badge: "Zero Defect",
    },
    {
      id: "wifi",
      title: "Wi-Fi Access Portal",
      description: "Secure visitor network credentials. Instant copy-paste and quick connection guide.",
      color: "from-cyan-500 to-blue-600",
      icon: Wifi,
      badge: "High-Speed",
    }
  ];

  return (
    <div className="space-y-10 py-4 animate-fade-in">
      {/* Premium Ambient Welcome Banner */}
      <section className="relative bg-slate-900 rounded-3xl p-8 md:p-12 overflow-hidden shadow-2xl flex-shrink-0">
        {/* Decorative Background Gradient */}
        <div className="absolute top-0 right-0 w-80 h-80 bg-indigo-500/25 rounded-full blur-[90px] -mr-32 -mt-32"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-500/15 rounded-full blur-[70px] -ml-24 -mb-24"></div>
        
        <div className="relative z-10 flex flex-col lg:flex-row lg:items-center justify-between gap-8">
          <div className="space-y-5">
            <span className="inline-block px-3 py-1 bg-indigo-500/20 text-indigo-300 text-xs font-bold rounded-full uppercase tracking-tighter">
              Visitor Portal
            </span>
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight tracking-tight">
              {getGreeting()},
              <span className="block text-indigo-400 mt-1">{visit.customerName}</span>
            </h1>
            <p className="text-slate-400 text-lg max-w-2xl font-light">
              We are honored to host you today for your strategic review, operations briefing, and factory tour.
            </p>
            
            <div className="flex flex-wrap items-center gap-y-4 gap-x-6 pt-2">
              <div>
                <span className="block text-xs uppercase text-slate-500 font-bold mb-1">Date</span>
                <span className="text-white font-medium">{formatDate(visit.visitDate)}</span>
              </div>
              <div className="hidden sm:block w-[1px] h-8 bg-slate-700"></div>
              <div>
                <span className="block text-xs uppercase text-slate-500 font-bold mb-1">Meeting Room</span>
                <span className="text-white font-medium">{visit.meetingRoom || "Executive Suite A"}</span>
              </div>
              <div className="hidden sm:block w-[1px] h-8 bg-slate-700"></div>
              <div>
                <span className="block text-xs uppercase text-slate-500 font-bold mb-1">Primary Host</span>
                <span className="text-white font-medium">{visit.hostTeam?.[0] || "Marcus Vane"}</span>
              </div>
            </div>
          </div>

          <div className="flex-shrink-0 self-start lg:self-center pt-4 lg:pt-0">
            <button
              id="cta-todays-visit"
              onClick={() => onNavigate("agenda")}
              className="group inline-flex items-center space-x-2 px-6 py-3.5 rounded-xl bg-white text-slate-900 font-semibold text-base transition-all duration-300 hover:bg-indigo-50 hover:scale-[1.02] shadow-lg hover:shadow-indigo-500/20"
            >
              <span>View Agenda</span>
              <ArrowRight className="w-5 h-5 transition-transform duration-200 group-hover:translate-x-1" />
            </button>
          </div>
        </div>
      </section>

      {/* SVI HQ Logistics Context (Meeting Room, Host Team, Lunch) */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Hosting Team Card */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between shadow-sm group hover:border-indigo-300 hover:shadow-md transition-all duration-300">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2.5 rounded-xl bg-slate-50 text-slate-600 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="font-sans font-bold text-slate-950 text-base">Your SVI Hosts</h3>
            </div>
            <ul className="space-y-2.5">
              {visit.hostTeam?.map((host, idx) => (
                <li key={idx} className="text-slate-600 text-sm flex items-start space-x-2">
                  <span className="text-indigo-400 font-bold font-mono mt-0.5">•</span>
                  <span>{host}</span>
                </li>
              )) || <li className="text-slate-400 text-sm italic">Hosts will be assigned on arrival.</li>}
            </ul>
          </div>
          <div className="mt-6 pt-4 border-t border-slate-100 text-xs font-mono text-slate-400">
            SVI Relations & Operations
          </div>
        </div>

        {/* Visitor Delegation List */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between shadow-sm group hover:border-indigo-300 hover:shadow-md transition-all duration-300">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2.5 rounded-xl bg-slate-50 text-slate-600 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                <Users className="w-5 h-5" />
              </div>
              <h3 className="font-sans font-bold text-slate-950 text-base">Visitor Delegation</h3>
            </div>
            <ul className="space-y-2">
              {visit.visitorList?.map((visitor) => (
                <li key={visitor.id} className="text-sm">
                  <span className="font-semibold text-slate-800">{visitor.name}</span>
                  <span className="text-slate-500 font-light block text-xs">{visitor.title}</span>
                </li>
              )) || <li className="text-slate-400 text-sm italic">No visitor names registered.</li>}
            </ul>
          </div>
          <div className="mt-6 pt-4 border-t border-slate-100 text-xs font-mono text-slate-400">
            {visit.customerName} Delegates
          </div>
        </div>

        {/* Catering & Lunch Card */}
        <div className="bg-white border border-slate-200 rounded-2xl p-6 flex flex-col justify-between shadow-sm group hover:border-indigo-300 hover:shadow-md transition-all duration-300">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="p-2.5 rounded-xl bg-slate-50 text-slate-600 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-colors">
                <Utensils className="w-5 h-5" />
              </div>
              <h3 className="font-sans font-bold text-slate-950 text-base">Lunch Catering</h3>
            </div>
            <ul className="space-y-2.5">
              {visit.lunchMenu?.map((dish, idx) => (
                <li key={idx} className="text-slate-600 text-sm flex items-start space-x-2">
                  <span className="text-indigo-400 font-bold mt-0.5">•</span>
                  <span>{dish}</span>
                </li>
              )) || <li className="text-slate-400 text-sm italic">Catering scheduled at local executive suite.</li>}
            </ul>
          </div>
          {visit.notes ? (
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-start space-x-2 text-xs text-indigo-800 bg-indigo-50/50 p-2 rounded-lg">
              <AlertCircle className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
              <p className="line-clamp-2">{visit.notes}</p>
            </div>
          ) : (
            <div className="mt-6 pt-4 border-t border-slate-100 text-xs font-mono text-slate-400">
              Executive Catering Menu
            </div>
          )}
        </div>
      </section>

      {/* Primary Grid Navigation */}
      <section className="space-y-5">
        <h2 className="text-2xl font-sans font-bold text-slate-900 tracking-tight">
          Explore SVI Resources
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {navCards.map((card) => {
            const Icon = card.icon;
            return (
              <div
                key={card.id}
                id={`card-${card.id}`}
                onClick={() => onNavigate(card.id)}
                className="group cursor-pointer bg-white border border-slate-200/70 rounded-2xl p-6 hover:border-slate-300 shadow-sm transition-all duration-300 hover:shadow-md hover:-translate-y-0.5 flex flex-col justify-between min-h-[190px]"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-xl bg-gradient-to-tr ${card.color} text-white shadow-md`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold font-mono bg-slate-100 text-slate-600 border border-slate-200">
                      {card.badge}
                    </span>
                  </div>
                  <h3 className="text-lg font-sans font-bold text-slate-900 mb-1.5 group-hover:text-indigo-600 transition-colors">
                    {card.title}
                  </h3>
                  <p className="text-sm text-slate-500 leading-relaxed font-light">
                    {card.description}
                  </p>
                </div>
                <div className="flex items-center text-xs font-semibold text-slate-900 group-hover:text-indigo-600 transition-colors mt-4">
                  <span>Open Section</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-1 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Downloads & Emergency Section */}
      <section className="bg-slate-50 border border-slate-200/60 rounded-2xl p-6 md:p-8 grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <h3 className="text-lg font-sans font-bold text-slate-900 mb-2 flex items-center space-x-2">
            <Download className="w-5 h-5 text-indigo-600" />
            <span>Documents & Resources</span>
          </h3>
          <p className="text-slate-500 text-sm mb-4 font-light">
            Keep critical files handy. These files are updated specifically for your visit.
          </p>
          <div className="space-y-2.5">
            {visit.documents?.map((doc) => (
              <a
                key={doc.id}
                href={doc.url}
                className="flex items-center justify-between p-3 rounded-xl bg-white border border-slate-200/70 hover:border-slate-300 transition-all text-slate-700 hover:text-slate-900 group shadow-sm"
              >
                <div className="flex items-center space-x-2.5 min-w-0">
                  <span className="px-2 py-1 rounded text-[10px] font-bold font-mono bg-red-100 text-red-700">
                    {doc.type}
                  </span>
                  <span className="text-sm font-medium truncate">{doc.title}</span>
                </div>
                <span className="text-xs font-mono text-slate-400 shrink-0">{doc.size}</span>
              </a>
            )) || <span className="text-sm text-slate-400 italic">No custom files linked.</span>}
          </div>
        </div>

        <div className="flex flex-col justify-between">
          <div>
            <h3 className="text-lg font-sans font-bold text-slate-900 mb-2">
              SVI Coordination Contact
            </h3>
            <p className="text-slate-500 text-sm mb-4 font-light">
              Should you require assistance, transportation coordinates, or dietary modifications during your stay.
            </p>
            <div className="p-4 rounded-xl bg-white border border-slate-200/70 space-y-2 shadow-sm">
              <div className="text-sm font-semibold text-slate-800">
                {visit.emergencyContact?.name || "SVI Liaison Officer"}
              </div>
              <div className="text-xs text-slate-400 font-mono">
                {visit.emergencyContact?.role || "Host Coordinator"}
              </div>
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-sm text-indigo-600 font-mono font-bold">
                <span>Phone Support:</span>
                <a href={`tel:${visit.emergencyContact?.phone || "+66021050456"}`}>
                  {visit.emergencyContact?.phone || "+66 (0) 2 105 0456"}
                </a>
              </div>
            </div>
          </div>
          <div className="text-xs text-slate-400 mt-4 leading-relaxed font-light">
            SVI Public Company Limited (HQ)<br />
            141-142 Moo 5, Tiwanon Road, Bang Kadi, Pathum Thani 12000, Thailand
          </div>
        </div>
      </section>
    </div>
  );
}
