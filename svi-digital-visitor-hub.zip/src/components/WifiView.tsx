import React, { useState } from "react";
import { Wifi, Copy, Check, ShieldAlert, Smartphone, Laptop, Globe } from "lucide-react";
import { Visit } from "../types";

interface WifiViewProps {
  visit: Visit;
}

export default function WifiView({ visit }: WifiViewProps) {
  const [copied, setCopied] = useState(false);

  const handleCopyPassword = () => {
    if (visit.wifiPassword) {
      navigator.clipboard.writeText(visit.wifiPassword);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-10 py-4 animate-fade-in">
      {/* Title section */}
      <div className="border-b border-slate-100 pb-5">
        <h1 className="text-3xl font-sans font-bold text-slate-900 tracking-tight">SVI Visitor Wi-Fi</h1>
        <p className="text-slate-500 text-sm font-light mt-1">
          High-speed secure connection details for guest delegation members on-site.
        </p>
      </div>

      {/* Main Grid content */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
        {/* Credentials Card (Left Column) */}
        <div className="md:col-span-7 bg-white border border-slate-200/80 rounded-2xl p-6 md:p-8 shadow-sm space-y-6">
          <div className="flex items-center space-x-3.5">
            <div className="p-3 rounded-xl bg-indigo-50 text-indigo-600 shadow-inner">
              <Wifi className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wide">
                Wireless Connection Details
              </span>
              <h2 className="text-xl font-bold text-slate-900">SVI Guest Network</h2>
            </div>
          </div>

          <div className="space-y-4 pt-2">
            {/* SSID Network */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center text-sm">
              <div className="space-y-0.5">
                <span className="text-xs font-mono text-slate-400 block">Wi-Fi Network SSID:</span>
                <span className="font-bold text-slate-800">SVI-GUEST-VIP</span>
              </div>
              <span className="px-2 py-0.5 bg-emerald-50 text-emerald-700 font-bold text-xs border border-emerald-100 rounded">
                Active
              </span>
            </div>

            {/* Username / User Account */}
            <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center text-sm">
              <div className="space-y-0.5">
                <span className="text-xs font-mono text-slate-400 block">Account/Username:</span>
                <span className="font-bold text-slate-800 font-mono">{visit.wifiUser || "SVI_Guest"}</span>
              </div>
            </div>

            {/* Security Password with Tactile Copy Trigger */}
            <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 text-white flex justify-between items-center text-sm relative group">
              <div className="space-y-0.5">
                <span className="text-xs font-mono text-slate-500 block">Network Security Password:</span>
                <span className="font-bold text-emerald-400 font-mono tracking-wide text-lg">
                  {visit.wifiPassword || "SVI_No_Password_Needed"}
                </span>
              </div>
              
              {visit.wifiPassword && (
                <button
                  id="btn-copy-wifi-pwd"
                  onClick={handleCopyPassword}
                  className={`flex items-center space-x-1.5 px-4 py-2.5 rounded-lg text-xs font-bold transition-all ${
                    copied
                      ? "bg-emerald-500 text-white"
                      : "bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 hover:text-white"
                  }`}
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Copy Password</span>
                    </>
                  )}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Instructions / Security Protocol (Right Column) */}
        <div className="md:col-span-5 space-y-6">
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-4">
            <h3 className="font-sans font-bold text-slate-900 text-sm uppercase tracking-wider">
              Connection Instructions
            </h3>
            
            <div className="space-y-4">
              <div className="flex items-start space-x-3 text-xs">
                <div className="w-6 h-6 rounded-full bg-slate-100 text-indigo-600 font-bold font-mono flex items-center justify-center shrink-0">
                  1
                </div>
                <div>
                  <span className="font-bold text-slate-800 block">Select Network</span>
                  <p className="text-slate-500 leading-relaxed font-light mt-0.5">
                    Navigate to your device's Wi-Fi panel and search for <span className="font-semibold text-slate-700">SVI-GUEST-VIP</span>.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 text-xs">
                <div className="w-6 h-6 rounded-full bg-slate-100 text-indigo-600 font-bold font-mono flex items-center justify-center shrink-0">
                  2
                </div>
                <div>
                  <span className="font-bold text-slate-800 block">Authenticate Account</span>
                  <p className="text-slate-500 leading-relaxed font-light mt-0.5">
                    A portal window may trigger. Input the username: <span className="font-semibold font-mono text-slate-700">{visit.wifiUser || "SVI_Guest"}</span>.
                  </p>
                </div>
              </div>

              <div className="flex items-start space-x-3 text-xs">
                <div className="w-6 h-6 rounded-full bg-slate-100 text-indigo-600 font-bold font-mono flex items-center justify-center shrink-0">
                  3
                </div>
                <div>
                  <span className="font-bold text-slate-800 block">Enter Security Key</span>
                  <p className="text-slate-500 leading-relaxed font-light mt-0.5">
                    Input or paste the generated key shown on the left. Press connect.
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-indigo-50/50 border border-indigo-100/50 flex items-start space-x-3 text-xs text-indigo-900">
            <ShieldAlert className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
            <div>
              <span className="font-bold">Enterprise Cyber Security Policy</span>
              <p className="mt-1 leading-relaxed font-light text-indigo-800/95">
                Our network is firewalled with active monitoring. Access to file servers or secure SMT industrial command grids is restricted. Guest internet speeds are priority-shaped up to 100 Mbps.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
