import React, { useState } from "react";
import { FACTORY_TOUR_STEPS } from "../data";
import * as LucideIcons from "lucide-react";

export default function FactoryTourView() {
  const [activeStepIndex, setActiveStepIndex] = useState(0);
  const [playVideo, setPlayVideo] = useState(true);

  const currentStep = FACTORY_TOUR_STEPS[activeStepIndex];

  // Helper to resolve Lucide Icon by name string
  const renderIcon = (name: string, className: string) => {
    const IconComponent = (LucideIcons as any)[name];
    if (IconComponent) {
      return <IconComponent className={className} />;
    }
    return <LucideIcons.Layers className={className} />;
  };

  return (
    <div className="space-y-10 py-4 animate-fade-in">
      {/* Page Title */}
      <div className="border-b border-slate-100 pb-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-sans font-bold text-slate-900 tracking-tight">Guided Factory Tour</h1>
          <p className="text-slate-500 text-sm font-light mt-1">
            An interactive walk through SVI's state-of-the-art assembly lines and testing facilities.
          </p>
        </div>
        <div className="flex items-center space-x-2 bg-emerald-50 border border-emerald-100 px-3 py-1.5 rounded-full shrink-0">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xs font-mono font-bold text-emerald-800 uppercase">
            Facility Status: Operational
          </span>
        </div>
      </div>

      {/* SVI Interactive Manufacturing Pipeline Pipeline (Timeline Nodes) */}
      <section className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm overflow-x-auto scrollbar-thin">
        <div className="min-w-[800px] flex items-center justify-between relative py-2">
          {/* Connecting Line Background */}
          <div className="absolute top-[28px] left-[40px] right-[40px] h-0.5 bg-slate-200 z-0" />
          
          {/* Active Progress Overlay Line */}
          <div
            className="absolute top-[28px] left-[40px] h-0.5 bg-gradient-to-r from-indigo-500 to-indigo-600 transition-all duration-500 z-0"
            style={{
              width: `${(activeStepIndex / (FACTORY_TOUR_STEPS.length - 1)) * 90}%`
            }}
          />

          {FACTORY_TOUR_STEPS.map((step, idx) => {
            const isActive = idx === activeStepIndex;
            const isCompleted = idx < activeStepIndex;
            return (
              <div
                key={step.id}
                onClick={() => setActiveStepIndex(idx)}
                className="flex flex-col items-center relative z-10 cursor-pointer group shrink-0"
                style={{ width: `${100 / FACTORY_TOUR_STEPS.length}%` }}
              >
                {/* Node Ring & Icon */}
                <div
                  id={`tour-node-${idx}`}
                  className={`w-11 h-11 rounded-full flex items-center justify-center border-2 transition-all duration-300 shadow-sm ${
                    isActive
                      ? "bg-slate-900 border-indigo-600 text-white scale-110"
                      : isCompleted
                      ? "bg-indigo-50 border-indigo-500 text-indigo-600 hover:bg-indigo-100"
                      : "bg-white border-slate-300 text-slate-500 hover:border-slate-400 hover:text-slate-700"
                  }`}
                >
                  {isCompleted ? (
                    <LucideIcons.Check className="w-5 h-5 font-bold" />
                  ) : (
                    renderIcon(step.iconName, "w-5 h-5")
                  )}
                </div>

                {/* Step Title Label */}
                <span className={`text-[11px] font-sans font-bold tracking-tight mt-3 text-center transition-colors max-w-[100px] truncate ${
                  isActive ? "text-indigo-600 font-extrabold" : "text-slate-500 group-hover:text-slate-800"
                }`}>
                  {step.title.split("&")[0].split("(")[0]}
                </span>
                
                {/* Step Subtitle / Number */}
                <span className="text-[9px] font-mono text-slate-400 mt-0.5">
                  Phase 0{idx + 1}
                </span>
              </div>
            );
          })}
        </div>
      </section>

      {/* Detail Block: Interactive Panel showing Video & Text */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Visual Media Showcase: Video Loop / High Res Photo (Left Column) */}
        <div className="lg:col-span-7 bg-white border border-slate-200/85 rounded-2xl p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase">
              Phase 0{activeStepIndex + 1} // SVI Production Visualizer
            </span>
            <div className="flex items-center space-x-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-mono font-semibold text-slate-600">Feed Active</span>
            </div>
          </div>

          {/* Interactive Player Frame */}
          <div className="relative rounded-xl overflow-hidden aspect-[16/10] bg-slate-950 border border-slate-800 shadow-inner group">
            {playVideo && currentStep.videoUrl ? (
              <video
                src={currentStep.videoUrl}
                autoPlay
                loop
                muted
                playsInline
                className="w-full h-full object-cover transition-opacity duration-500"
                referrerPolicy="no-referrer"
                onError={() => setPlayVideo(false)} // Fail gracefully to picture view
              />
            ) : (
              /* High-fidelity picture with custom graphic layout */
              <div
                className="w-full h-full bg-cover bg-center flex flex-col justify-between p-6 text-white"
                style={{ backgroundImage: `url('${currentStep.image}')` }}
              >
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-slate-900/30 to-slate-950/40" />
                
                {/* Simulated Digital Oscillosope overlay */}
                <div className="absolute bottom-6 right-6 w-32 h-14 border border-emerald-500/20 bg-black/60 rounded p-1.5 flex flex-col justify-between font-mono text-[8px] text-emerald-400 z-10">
                  <div className="flex justify-between">
                    <span>GRID_X: SMT</span>
                    <span>99.8%</span>
                  </div>
                  <div className="h-4 flex items-end justify-between space-x-0.5">
                    <div className="w-1 bg-emerald-500 h-2 animate-bounce-slow" />
                    <div className="w-1 bg-emerald-500 h-3 animate-bounce" />
                    <div className="w-1 bg-emerald-500 h-1 animate-bounce-fast" />
                    <div className="w-1 bg-emerald-500 h-4 animate-bounce" />
                    <div className="w-1 bg-emerald-500 h-2 animate-bounce-slow" />
                    <div className="w-1 bg-emerald-500 h-3 animate-bounce-fast" />
                  </div>
                </div>
              </div>
            )}

            {/* Bottom Overlay Label */}
            <div className="absolute bottom-0 inset-x-0 bg-gradient-to-t from-black/80 to-transparent p-5 text-white flex justify-between items-center z-10">
              <div>
                <span className="text-[10px] font-mono text-indigo-400 font-bold uppercase tracking-wide block">
                  Location feed
                </span>
                <span className="text-sm font-bold font-sans">{currentStep.subtitle}</span>
              </div>
              <button
                id="tour-video-toggle"
                onClick={() => setPlayVideo(!playVideo)}
                className="px-3 py-1 bg-white/10 hover:bg-white/20 text-white rounded text-xs font-mono border border-white/10 transition-all"
              >
                {playVideo ? "Static View" : "Video Loop"}
              </button>
            </div>
          </div>
        </div>

        {/* Technical Explanations & Key Metrics (Right Column) */}
        <div className="lg:col-span-5 space-y-6">
          <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-sm space-y-5">
            <div>
              <span className="text-xs font-mono font-bold text-indigo-600 block uppercase">
                Step 0{activeStepIndex + 1} of 07
              </span>
              <h2 className="text-2xl font-sans font-bold text-slate-900 mt-1">
                {currentStep.title}
              </h2>
              <p className="text-slate-500 text-sm font-light mt-1 italic">
                {currentStep.subtitle}
              </p>
            </div>

            <p className="text-slate-600 text-sm leading-relaxed font-light">
              {currentStep.explanation}
            </p>

            {/* Standard Metrics Panel */}
            <div className="space-y-3 pt-4 border-t border-slate-100">
              <h4 className="text-xs font-mono font-bold text-slate-400 uppercase">
                Key Performance Indicators (KPIs)
              </h4>
              <div className="space-y-2.5">
                {currentStep.metrics.map((metric, idx) => (
                  <div key={idx} className="flex justify-between items-center p-2.5 rounded-lg bg-slate-50 border border-slate-100 text-xs font-mono">
                    <span className="text-slate-500">{metric.label}:</span>
                    <span className="font-bold text-slate-800">{metric.value}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Guidelines info for visitors */}
          <div className="p-4 rounded-xl bg-slate-900 text-white border border-slate-800 space-y-2.5 shadow-md">
            <h4 className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-wide flex items-center space-x-1.5">
              <LucideIcons.ShieldAlert className="w-4 h-4 shrink-0" />
              <span>Visitor Safety & ESD Rules</span>
            </h4>
            <p className="text-[11px] text-slate-300 font-light leading-relaxed">
              Before crossing the ESD threshold on our SMT line, please wear the provided static dissipative lab coat, heel straps, and safety goggles. Mobile photography is strictly restricted to designated zones.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
