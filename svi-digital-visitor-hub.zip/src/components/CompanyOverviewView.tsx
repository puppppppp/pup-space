import React, { useState, useRef, useEffect } from "react";
import {
  Globe,
  Users,
  Trophy,
  Download,
  Award,
  ChevronLeft,
  ChevronRight,
  ShieldCheck,
  FileText,
  TrendingUp,
  Cpu,
  Zap,
  Phone,
  Mail,
  Activity,
  Heart,
  Calendar,
  Layers,
  MapPin,
  Search,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Minimize2,
  Printer,
  Sliders,
  CheckCircle2,
  Eye,
  SlidersHorizontal,
  Upload,
  Trash2,
  RefreshCw
} from "lucide-react";

// IndexedDB persistence helpers for exact PDF file upload
const savePdfToDb = async (file: File) => {
  return new Promise<void>((resolve, reject) => {
    const request = indexedDB.open("svi_pdf_store", 1);
    request.onupgradeneeded = (e: any) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains("pdfs")) {
        db.createObjectStore("pdfs");
      }
    };
    request.onsuccess = (e: any) => {
      const db = e.target.result;
      const transaction = db.transaction("pdfs", "readwrite");
      const store = transaction.objectStore("pdfs");
      store.put(file, "current_pdf");
      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);
    };
    request.onerror = () => reject(request.error);
  });
};

const loadPdfFromDb = async (): Promise<File | null> => {
  return new Promise((resolve) => {
    const request = indexedDB.open("svi_pdf_store", 1);
    request.onupgradeneeded = (e: any) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains("pdfs")) {
        db.createObjectStore("pdfs");
      }
    };
    request.onsuccess = (e: any) => {
      const db = e.target.result;
      const transaction = db.transaction("pdfs", "readonly");
      const store = transaction.objectStore("pdfs");
      const getReq = store.get("current_pdf");
      getReq.onsuccess = () => resolve(getReq.result || null);
      getReq.onerror = () => resolve(null);
    };
    request.onerror = () => resolve(null);
  });
};

const deletePdfFromDb = async () => {
  return new Promise<void>((resolve) => {
    const request = indexedDB.open("svi_pdf_store", 1);
    request.onsuccess = (e: any) => {
      const db = e.target.result;
      const transaction = db.transaction("pdfs", "readwrite");
      const store = transaction.objectStore("pdfs");
      store.delete("current_pdf");
      transaction.oncomplete = () => resolve();
    };
  });
};

export default function CompanyOverviewView() {
  const [viewMode, setViewMode] = useState<"pdf" | "slides" | "custom">("custom");
  const [activePage, setActivePage] = useState(1);
  const [zoom, setZoom] = useState(100);
  const [showSidebar, setShowSidebar] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  const [isFullscreen, setIsAdminFullscreen] = useState(false);
  
  const [customPdf, setCustomPdf] = useState<File | null>(null);
  const [customPdfUrl, setCustomPdfUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const pageRefs = useRef<{ [key: number]: HTMLDivElement | null }>({});

  const totalPages = 36;

  // Load PDF from IndexedDB on mount
  useEffect(() => {
    loadPdfFromDb().then((file) => {
      if (file) {
        setCustomPdf(file);
        setCustomPdfUrl(URL.createObjectURL(file));
        setViewMode("custom"); // Switch to custom view by default if a file exists
      }
    });

    return () => {
      if (customPdfUrl) {
        URL.revokeObjectURL(customPdfUrl);
      }
    };
  }, []);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      await handleFileUpload(file);
    }
  };

  const handleFileUpload = async (file: File) => {
    if (file.type !== "application/pdf") {
      alert("Please select a valid PDF file.");
      return;
    }
    try {
      await savePdfToDb(file);
      setCustomPdf(file);
      if (customPdfUrl) {
        URL.revokeObjectURL(customPdfUrl);
      }
      const newUrl = URL.createObjectURL(file);
      setCustomPdfUrl(newUrl);
      setViewMode("custom");
    } catch (err) {
      console.error("Failed to persist PDF:", err);
      setCustomPdf(file);
      const newUrl = URL.createObjectURL(file);
      setCustomPdfUrl(newUrl);
      setViewMode("custom");
    }
  };

  const handleRemovePdf = async () => {
    if (confirm("Are you sure you want to remove the uploaded PDF file?")) {
      await deletePdfFromDb();
      setCustomPdf(null);
      if (customPdfUrl) {
        URL.revokeObjectURL(customPdfUrl);
        setCustomPdfUrl(null);
      }
      setViewMode("custom");
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = () => {
    setIsDragging(false);
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      await handleFileUpload(file);
    }
  };

  // Pages database mapping the actual 36 slides of the SVI PDF
  const pagesData = [
    {
      pageNum: 1,
      section: "Title Cover",
      title: "Company Profile",
      subtitle: "Superior Service, Highest Quality",
      category: "CORPORATE OVERVIEW",
      content: (
        <div className="flex flex-col items-center justify-center text-center h-full relative p-8 text-slate-900">
          <div className="absolute top-4 left-6">
            <span className="text-[10px] font-mono tracking-widest text-red-600 font-extrabold uppercase">SVI HQ PORTAL</span>
          </div>
          <div className="w-24 h-24 mb-6">
            <svg className="w-full h-full" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
              <circle cx="50" cy="50" r="40" stroke="#E11B22" strokeWidth="3" />
              <line x1="50" y1="10" x2="50" y2="90" stroke="#E11B22" strokeWidth="3" />
              <line x1="10" y1="50" x2="90" y2="50" stroke="#E11B22" strokeWidth="3" />
              <path d="M 50 10 A 22 40 0 0 0 50 90" stroke="#E11B22" strokeWidth="3" fill="none" />
              <path d="M 50 10 A 22 40 0 0 1 50 90" stroke="#E11B22" strokeWidth="3" fill="none" />
              <path d="M 12 35 A 40 18 0 0 1 88 35" stroke="#E11B22" strokeWidth="3" fill="none" />
              <path d="M 12 65 A 40 18 0 0 0 88 65" stroke="#E11B22" strokeWidth="3" fill="none" />
            </svg>
          </div>
          <h1 className="text-4xl font-extrabold text-blue-900 tracking-tight leading-none mb-4">
            SVI
          </h1>
          <div className="h-[2px] w-24 bg-red-500 mb-4" />
          <h2 className="text-2xl font-bold text-slate-800 tracking-wide mb-1">
            Company Profile
          </h2>
          <p className="text-slate-500 text-sm font-medium tracking-wide">
            Superior Service, Highest Quality
          </p>
          <div className="mt-8 text-[10px] font-mono text-slate-400 bg-slate-100 px-3 py-1 rounded-full uppercase">
            Official Investor & Partner Briefing Deck
          </div>
        </div>
      )
    },
    {
      pageNum: 2,
      section: "Value Mandate",
      title: "Superior Service, Highest Quality",
      subtitle: "Adaptability as a cornerstone of SVI value delivery",
      category: "CORPORATE OVERVIEW",
      content: (
        <div className="flex flex-col justify-between h-full p-8 text-slate-800">
          <div className="space-y-4">
            <span className="text-[10px] font-mono font-bold text-red-500 tracking-widest uppercase">OUR FOUNDATIONAL FOCUS</span>
            <h3 className="text-xl font-bold text-blue-950">Superior Service, Highest Quality</h3>
            <p className="text-slate-600 text-sm leading-relaxed font-light">
              We understand that the future is shaped by those who are able to adapt quickly and efficiently, which is why we strictly prioritize and value:
            </p>
          </div>
          
          <div className="grid grid-cols-2 gap-4 my-auto">
            {[
              { val: "Reliability", desc: "Absolute compliance with timeline commitments" },
              { val: "Agility", desc: "Fast engineering adaptations & line scaling" },
              { val: "Innovation", desc: "State-of-the-art tooling & smart logistics" },
              { val: "Global Mindset", desc: "Cross-border compliance & multi-site backups" }
            ].map((v, i) => (
              <div key={i} className="bg-slate-50 border border-slate-150 p-4 rounded-xl">
                <span className="font-bold text-slate-900 text-sm block">{v.val}</span>
                <span className="text-xs text-slate-500 font-light block mt-1">{v.desc}</span>
              </div>
            ))}
          </div>

          <div className="text-[9px] font-mono text-slate-400 border-t border-slate-100 pt-2">
            SVI PUBLIC CO. LTD // EXECUTIVE OVERVIEW
          </div>
        </div>
      )
    },
    {
      pageNum: 3,
      section: "Mission Pillars",
      title: "Promise, Vision & Mission",
      subtitle: "Unwavering commitment to partnership standards",
      category: "STRATEGIC FOUNDATION",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-full items-stretch p-6 text-slate-800">
          <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl flex flex-col justify-between">
            <div>
              <span className="text-red-500 text-[10px] font-mono font-bold tracking-widest uppercase">OUR PILLARS</span>
              <h4 className="text-sm font-bold text-blue-950 mt-1 mb-2">Promise</h4>
              <p className="text-slate-600 text-xs leading-relaxed font-light">
                Unwavering support, unbreakable trust, unrivalled performance, and life-long strategic partnership.
              </p>
            </div>
            <div className="text-[9px] font-mono text-slate-400 uppercase">SVI CLIENT ASSURANCE</div>
          </div>

          <div className="bg-blue-50/50 border border-blue-100 p-4 rounded-xl flex flex-col justify-between">
            <div>
              <span className="text-blue-500 text-[10px] font-mono font-bold tracking-widest uppercase">FORWARD LOOKING</span>
              <h4 className="text-sm font-bold text-blue-950 mt-1 mb-2">Vision</h4>
              <p className="text-slate-600 text-xs leading-relaxed font-light">
                Premier EMS partner, leveraging advanced robotics technology, accelerating digital product innovation.
              </p>
            </div>
            <div className="text-[9px] font-mono text-blue-400 uppercase font-bold">SVI FORWARD INTENT</div>
          </div>

          <div className="bg-slate-50 border border-slate-200 p-4 rounded-xl flex flex-col justify-between">
            <div>
              <span className="text-emerald-500 text-[10px] font-mono font-bold tracking-widest uppercase">DAILY EXECUTION</span>
              <h4 className="text-sm font-bold text-blue-950 mt-1 mb-2">Mission</h4>
              <p className="text-slate-600 text-xs leading-relaxed font-light">
                Consistently increasing value. Safe and sustainable. Absolute trust, mutual respect, and operational integrity.
              </p>
            </div>
            <div className="text-[9px] font-mono text-emerald-500 uppercase">SVI INTEGRITY ENGINE</div>
          </div>
        </div>
      )
    },
    {
      pageNum: 4,
      section: "Section Header",
      title: "Key Insights About SVI",
      subtitle: "Overview of global credentials & operational capacity",
      category: "SECTION DIVIDER",
      content: (
        <div className="flex flex-col items-center justify-center text-center h-full bg-slate-900 text-white p-8">
          <Cpu className="w-16 h-16 text-indigo-400 mb-4 animate-pulse" />
          <span className="text-xs font-mono text-indigo-300 uppercase tracking-widest">CHAPTER 01</span>
          <h2 className="text-3xl font-bold mt-1 text-white">Key Insights About SVI</h2>
          <div className="h-[2px] w-16 bg-red-500 mt-3 mb-2" />
          <p className="text-slate-400 text-xs max-w-sm font-light">
            Comprehensive breakdown of SVI worldwide manufacturing capacity, financial records, and assembly segments.
          </p>
        </div>
      )
    },
    {
      pageNum: 5,
      section: "At A Glance",
      title: "SVI At A Glance",
      subtitle: "EMS leadership with 40+ years of active global expertise",
      category: "CORPORATE OVERVIEW",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="grid grid-cols-4 gap-4 my-auto text-center">
            {[
              { val: "+574 MUSD", label: "Annual Revenue", sub: "Robust fiscal basis" },
              { val: "Top 50", label: "EMS Worldwide", sub: "Global ranking pedigree" },
              { val: "6 Sites", label: "Production sites", sub: "Global manufacturing grid" },
              { val: "+6,500", label: "Skilled Employees", sub: "Engineers & operators" }
            ].map((m, i) => (
              <div key={i} className="bg-slate-50 border border-slate-150 p-4 rounded-xl">
                <span className="text-xl font-extrabold text-blue-900 block">{m.val}</span>
                <span className="text-xs font-bold text-slate-800 block mt-1">{m.label}</span>
                <span className="text-[9px] text-slate-500 block font-light mt-0.5">{m.sub}</span>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-4 border-t border-slate-100 pt-4 text-[10px] text-slate-600">
            <div>
              <strong>40+ Years' Expertise:</strong> Deep domain experience in safety-critical manufacturing.
            </div>
            <div>
              <strong>Supply Chain Security:</strong> Established global networks with key strategic partners.
            </div>
            <div>
              <strong>Financial Stability:</strong> Consistently positive cash-flows and high creditworthiness.
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 6,
      section: "Growth Timeline",
      title: "Corporate Growth Timeline",
      subtitle: "Consistent international expansion from 1985 to 2026",
      category: "TIMELINE & MILESTONES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="grid grid-cols-3 gap-x-4 gap-y-2.5 my-auto text-xs max-h-[220px] overflow-y-auto pr-1">
            {[
              { year: "1985", text: "Founded in Bangkok, Thailand" },
              { year: "1989", text: "IPO on Stock Exchange of Thailand" },
              { year: "2000", text: "European Sales office in Denmark" },
              { year: "2004", text: "Built Brand New HQ in Pathum Thani" },
              { year: "2013", text: "Strategic Headquarters Expansion" },
              { year: "2016", text: "Acquired plants in Austria & Slovakia" },
              { year: "2019", text: "New Plant in Phnom Penh, Cambodia" },
              { year: "2021", text: "Acquired Tohoku Solutions (Ayutthaya)" },
              { year: "2024", text: "New site in Washington, U.S.A." },
              { year: "2025", text: "Tech & Innovation Centre in China" },
              { year: "2026", text: "New PCB Facility, Pathum Thani HQ" }
            ].map((m, i) => (
              <div key={i} className="flex items-start space-x-2 p-1.5 bg-slate-50 rounded-lg border border-slate-100">
                <span className="font-mono font-bold text-[10px] bg-red-100 text-red-600 px-1 py-0.5 rounded shrink-0">
                  {m.year}
                </span>
                <span className="text-[10px] text-slate-600 font-medium leading-tight">{m.text}</span>
              </div>
            ))}
          </div>
        </div>
      )
    },
    {
      pageNum: 7,
      section: "Revenue Record",
      title: "Global Annual Revenue",
      subtitle: "CAGR of 8.4% demonstrating strong year-over-year financial performance",
      category: "FINANCIAL STABILITY",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="flex justify-between items-center mb-2">
            <span className="text-xs font-mono font-bold text-slate-500 uppercase">TURNOVER IN M USD</span>
            <span className="text-[10px] font-mono font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">CAGR: 8.4%</span>
          </div>
          
          <div className="flex-1 flex items-end justify-between gap-1 border-b border-slate-200 pb-2">
            {[312, 370, 485, 484, 489, 544, 740, 655, 624, 574, 700].map((v, i) => {
              const years = ["2016", "2017", "2018", "2019", "2020", "2021", "2022", "2023", "2024", "2025", "2026E"];
              const isProj = years[i] === "2026E";
              const percentHeight = (v / 740) * 100;
              return (
                <div key={i} className="flex-1 flex flex-col items-center">
                  <span className="text-[8px] font-mono font-bold text-slate-500">${v}M</span>
                  <div
                    style={{ height: `${percentHeight * 0.9}px` }}
                    className={`w-full max-w-[14px] rounded-t-sm ${
                      isProj ? "bg-red-500 shadow-sm" : "bg-blue-900"
                    }`}
                  />
                  <span className="text-[8px] font-mono font-medium mt-1 text-slate-400">{years[i]}</span>
                </div>
              );
            })}
          </div>
        </div>
      )
    },
    {
      pageNum: 8,
      section: "Market Segments",
      title: "Revenue by Market Segment",
      subtitle: "Well-diversified high-complexity portfolio representing global safety-critical sectors",
      category: "BUSINESS DIVERSIFICATION",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="grid grid-cols-2 gap-x-6 gap-y-3 my-auto">
            {[
              { name: "Communication & IoT", share: "32%", color: "bg-blue-600" },
              { name: "Industrial & Automation", share: "30%", color: "bg-red-500" },
              { name: "Automotive & Public Transport", share: "11%", color: "bg-teal-500" },
              { name: "Audio Video & Security", share: "10%", color: "bg-amber-500" },
              { name: "CleanTech & Energy", share: "5%", color: "bg-sky-500" },
              { name: "Other Tech sectors", share: "12%", color: "bg-slate-400" }
            ].map((s, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-[11px] font-semibold text-slate-700">
                  <span className="truncate">{s.name}</span>
                  <span>{s.share}</span>
                </div>
                <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div className={`h-full ${s.color}`} style={{ width: s.share }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )
    },
    {
      pageNum: 9,
      section: "Product Categories",
      title: "Revenue by Product Category",
      subtitle: "High-value systems integration and high-mix board assemblies",
      category: "BUSINESS DIVERSIFICATION",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-4 my-auto">
            {[
              { name: "73% Box-Build", desc: "Complete system assemblies, testing, and mechanical enclosures", color: "bg-blue-900", percent: 73 },
              { name: "22% PCBA Placement", desc: "Surface Mount Technology (SMT) high-speed electronic placement", color: "bg-red-500", percent: 22 },
              { name: "5% Cable Harnesses & Mechanicals", desc: "Custom cable assemblies, overmolding, and tooling structures", color: "bg-teal-500", percent: 5 }
            ].map((p, i) => (
              <div key={i} className="space-y-1.5">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-bold text-slate-800">{p.name}</span>
                  <span className="text-[10px] text-slate-500 font-light">{p.desc}</span>
                </div>
                <div className="h-2 w-full bg-slate-100 rounded-full overflow-hidden">
                  <div className={`h-full ${p.color}`} style={{ width: `${p.percent}%` }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      )
    },
    {
      pageNum: 10,
      section: "Global Footprint",
      title: "Global Footprint",
      subtitle: "1 Strategic Headquarters, 6 Production Plants, and 7 Sales divisions worldwide",
      category: "GLOBAL REACH",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="grid grid-cols-3 gap-3 my-auto">
            {[
              { count: "1 HQ", val: "Bangkok, Thailand", desc: "Strategic centralized planning & administration" },
              { count: "6 Sites", val: "Asia, Europe & USA", desc: "82K m² Thailand HQ, Cambodia, Austria, Slovakia, USA" },
              { count: "7 Offices", val: "Scandinavian & Asia", desc: "Denmark, Germany, China, Japan, USA, Thailand, Austria" }
            ].map((f, i) => (
              <div key={i} className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex flex-col justify-between">
                <div>
                  <span className="text-red-500 font-bold font-mono text-sm block">{f.count}</span>
                  <span className="text-xs font-bold text-slate-800 block mt-1">{f.val}</span>
                  <p className="text-[10px] text-slate-500 font-light leading-relaxed mt-1">{f.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )
    },
    {
      pageNum: 11,
      section: "Corporate Structure",
      title: "Global Corporate Structure",
      subtitle: "Cohesive organizational layout coordinating sales and manufacturing divisions",
      category: "GLOBAL REACH",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="p-3.5 bg-blue-50/50 border border-blue-100 rounded-xl text-center mb-3">
            <span className="text-xs font-mono font-bold text-blue-600 block uppercase">Strategic Umbrella Entity</span>
            <span className="text-sm font-black text-blue-900 block mt-0.5">SVI PUBLIC CO. LTD. (THAILAND)</span>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-150">
              <span className="text-[10px] font-mono font-bold text-slate-500 uppercase block">7 Worldwide Sales Units</span>
              <span className="text-xs text-slate-700 leading-relaxed block mt-1">
                SVI Denmark, SVI Germany, SVI Japan Ltd, SVI China (Hangzhou), SVI Austria, SVI USA
              </span>
            </div>
            <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-150">
              <span className="text-[10px] font-mono font-bold text-slate-500 uppercase block">6 High-Volume Assembly Plants</span>
              <span className="text-xs text-slate-700 leading-relaxed block mt-1">
                SVI Thailand HQ, Tohoku Solutions, SVI Cambodia, SVI Slovakia, SVI Austria, SVI USA (WA)
              </span>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 12,
      section: "Certifications",
      title: "Our Certifications",
      subtitle: "Maintaining maximum international compliance across medical, automotive, and aerospace fields",
      category: "COMPLIANCE & QUALITY",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="grid grid-cols-4 gap-2 my-auto text-center">
            {[
              { val: "ISO 9001", cat: "Quality Systems" },
              { val: "ISO 13485", cat: "Medical Devices" },
              { val: "IATF 16949", cat: "Automotive Core" },
              { val: "AS/EN 9100", cat: "Aerospace Avionics" },
              { val: "ISO 14001", cat: "Environmental" },
              { val: "ISO 45001", cat: "Health & Safety" },
              { val: "ISO 27001", cat: "Information Security" },
              { val: "UL / ATEX", cat: "Explosive Atmospheres" }
            ].map((c, i) => (
              <div key={i} className="p-2 bg-slate-50 rounded-lg border border-slate-150 flex flex-col justify-center">
                <span className="font-mono font-extrabold text-blue-900 text-xs block">{c.val}</span>
                <span className="text-[9px] text-slate-500 font-light block mt-0.5 leading-none">{c.cat}</span>
              </div>
            ))}
          </div>
          <div className="text-[9px] text-slate-400 font-mono border-t border-slate-100 pt-2 text-center">
            ROHS COMPLIANT // REACH COMPLIANT // CONFLICT-FREE SMELTER TRACEABLE
          </div>
        </div>
      )
    },
    {
      pageNum: 13,
      section: "Section Header",
      title: "Production Facilities",
      subtitle: "Overview of global sites and specific cleanroom specifications",
      category: "SECTION DIVIDER",
      content: (
        <div className="flex flex-col items-center justify-center text-center h-full bg-slate-900 text-white p-8">
          <Layers className="w-16 h-16 text-red-400 mb-4 animate-pulse" />
          <span className="text-xs font-mono text-red-300 uppercase tracking-widest">CHAPTER 02</span>
          <h2 className="text-3xl font-bold mt-1 text-white">SVI Production Facilities</h2>
          <div className="h-[2px] w-16 bg-blue-500 mt-3 mb-2" />
          <p className="text-slate-400 text-xs max-w-sm font-light">
            Deep-dive specifications, floor area, line allocations, and personnel count of each factory site.
          </p>
        </div>
      )
    },
    {
      pageNum: 14,
      section: "Facility Specifics",
      title: "SVI THAILAND Headquarters",
      subtitle: "End-to-end manufacturing and strategic high-volume automated lines",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-2 mb-2">
            <h4 className="font-bold text-sm text-blue-900">Pathum Thani HQ (Bang Kadi Industrial Park)</h4>
            <p className="text-[11px] text-slate-600 font-light leading-relaxed">
              SVI Thailand delivers end-to-end electronic assemblies with 24/7 continuous operations, SMT, Through-Hole, COB, and full Box Build capabilities.
            </p>
          </div>
          <div className="grid grid-cols-4 gap-2.5 my-auto text-center text-xs">
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">82,000 m²</span>
              <span className="text-[9px] text-slate-500">Floor space</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">25 SMT</span>
              <span className="text-[9px] text-slate-500">Placement lines</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">10K Class</span>
              <span className="text-[9px] text-slate-500">Cleanroom</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">3,600</span>
              <span className="text-[9px] text-slate-500">Employees</span>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 15,
      section: "Facility Specifics",
      title: "SVI THAILAND Tohoku Solutions",
      subtitle: "Specialized plastic injection molding and heavy electrical mechanical overmolding",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-2 mb-2">
            <h4 className="font-bold text-sm text-blue-900">Tohoku Solutions Plant (Ayutthaya, Thailand)</h4>
            <p className="text-[11px] text-slate-600 font-light leading-relaxed">
              Acquired in 2021, Tohoku Solutions expands SVI capabilities into heavy mechanical overmolding, plastic injection molding, and complex cable harness assembly.
            </p>
          </div>
          <div className="grid grid-cols-4 gap-2.5 my-auto text-center text-xs">
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">45,000 m²</span>
              <span className="text-[9px] text-slate-500">Facility space</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">2 SMT</span>
              <span className="text-[9px] text-slate-500">Lines</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">Plastic & Metal</span>
              <span className="text-[9px] text-slate-500">Die/Mold Mfg</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">900</span>
              <span className="text-[9px] text-slate-500">Employees</span>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 16,
      section: "Facility Specifics",
      title: "SVI CAMBODIA",
      subtitle: "High-volume assembly utilizing competitive regional cost structures",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-2 mb-2">
            <h4 className="font-bold text-sm text-blue-900">Phnom Penh Facility (AEC Zone)</h4>
            <p className="text-[11px] text-slate-600 font-light leading-relaxed">
              Provides cost-optimized volume assemblies for consumer IoT, high-speed camera builds, and custom optical modules.
            </p>
          </div>
          <div className="grid grid-cols-4 gap-2.5 my-auto text-center text-xs">
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">67,000 m²</span>
              <span className="text-[9px] text-slate-500">Operational space</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">10 SMT</span>
              <span className="text-[9px] text-slate-500">Lines</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">Camera Build</span>
              <span className="text-[9px] text-slate-500">Optics assembly</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">800+</span>
              <span className="text-[9px] text-slate-500">Employees</span>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 17,
      section: "Footprint Details",
      title: "Footprint in Asia",
      subtitle: "Close logistical integration with major regional airport hubs",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-3.5 my-auto">
            <div className="flex items-start space-x-3 text-xs">
              <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <div>
                <strong>SVI Bangkok (HQ):</strong> 35 km (45 min) from Suvarnabhumi Airport / 15 km (20 min) from Don Mueang Airport.
              </div>
            </div>
            <div className="flex items-start space-x-3 text-xs">
              <MapPin className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
              <div>
                <strong>SVI Tohoku Solutions:</strong> 87 km (70 min) from Suvarnabhumi Airport.
              </div>
            </div>
            <div className="flex items-start space-x-3 text-xs">
              <MapPin className="w-4 h-4 text-teal-500 shrink-0 mt-0.5" />
              <div>
                <strong>SVI Cambodia:</strong> 15 km (30 min) from Phnom Penh Airport / 1 hour flight time to Don Mueang Airport.
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 18,
      section: "Facility Specifics",
      title: "SVI AUSTRIA",
      subtitle: "High-end European design testing, product development, and volume assembly",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-2 mb-2">
            <h4 className="font-bold text-sm text-blue-900">Deutschlandsberg Facility (Austria)</h4>
            <p className="text-[11px] text-slate-600 font-light leading-relaxed">
              Acts as the central gateway for European clients. Specialized in initial rapid prototyping, functional design testing, and safety-critical box builds.
            </p>
          </div>
          <div className="grid grid-cols-4 gap-2.5 my-auto text-center text-xs">
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">8,400 m²</span>
              <span className="text-[9px] text-slate-500">Floor space</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">3 SMT</span>
              <span className="text-[9px] text-slate-500">Lines</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">Design Tester</span>
              <span className="text-[9px] text-slate-500">Development R&D</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">290</span>
              <span className="text-[9px] text-slate-500">Employees</span>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 19,
      section: "Facility Specifics",
      title: "SVI SLOVAKIA",
      subtitle: "Competitively priced volume manufacturing inside the European Union boundary",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-2 mb-2">
            <h4 className="font-bold text-sm text-blue-900">Liptovsky Hradok Facility (Slovakia)</h4>
            <p className="text-[11px] text-slate-600 font-light leading-relaxed">
              Provides volume assembly within the EU trade boundary, avoiding import tariffs and streamlining delivery for European strategic partners.
            </p>
          </div>
          <div className="grid grid-cols-4 gap-2.5 my-auto text-center text-xs">
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">11,400 m²</span>
              <span className="text-[9px] text-slate-500">Facility space</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">2 SMT</span>
              <span className="text-[9px] text-slate-500">Lines</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">Box Build</span>
              <span className="text-[9px] text-slate-500">SMT & Wire assembly</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">320</span>
              <span className="text-[9px] text-slate-500">Employees</span>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 20,
      section: "Footprint Details",
      title: "Footprint in Europe",
      subtitle: "Optimal logisitical coordination across European industrial corridors",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-3 my-auto">
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-start space-x-3 text-xs">
              <MapPin className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
              <div>
                <strong>SVI Austria:</strong> 35 km (30 min) from Graz Airport / 195 km (2h 15 min) from Vienna International Airport.
              </div>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-start space-x-3 text-xs">
              <MapPin className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
              <div>
                <strong>SVI Slovakia:</strong> 197 km (2h 45 min) from Kraków Airport (Poland) / 348 km (4h) from Vienna International Airport.
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 21,
      section: "Facility Specifics",
      title: "USA",
      subtitle: "Onshore local production and testing support for North American market",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-2 mb-2">
            <h4 className="font-bold text-sm text-blue-900">SVI Electronics (USA) LLC (Vancouver, WA)</h4>
            <p className="text-[11px] text-slate-600 font-light leading-relaxed">
              Provides local manufacturing support with trained operators, flexible workforce scaling, and deep technological backing from SVI subject matter experts in Thailand.
            </p>
          </div>
          <div className="grid grid-cols-3 gap-2.5 my-auto text-center text-xs">
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">86,200 ft²</span>
              <span className="text-[9px] text-slate-500">Mfg space</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">8,700 ft²</span>
              <span className="text-[9px] text-slate-500">ISO Class 6 Cleanroom</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900">32,300 ft²</span>
              <span className="text-[9px] text-slate-500">Warehouse space</span>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 22,
      section: "Footprint Details",
      title: "Footprint in USA",
      subtitle: "Highly integrated logistics close to Pacific Northwest technology corridors",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-3.5 my-auto">
            <div className="flex items-start space-x-3 text-xs">
              <MapPin className="w-4 h-4 text-red-500 shrink-0 mt-0.5" />
              <div>
                <strong>15-minute drive:</strong> Directly connects to Vancouver city center.
              </div>
            </div>
            <div className="flex items-start space-x-3 text-xs">
              <MapPin className="w-4 h-4 text-blue-500 shrink-0 mt-0.5" />
              <div>
                <strong>17-minute drive:</strong> Fast access to Portland International Airport (PDX).
              </div>
            </div>
            <div className="flex items-start space-x-3 text-xs">
              <MapPin className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
              <div>
                <strong>1 hour 45 min flight:</strong> Rapid connection directly to Silicon Valley, California.
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 23,
      section: "Manufacturing Capabilities",
      title: "Integrated Manufacturing & Test Capabilities",
      subtitle: "Comprehensive end-to-end tooling, utilities, and testing setups",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="grid grid-cols-3 gap-3 my-auto text-xs">
            <div className="p-2.5 bg-slate-50 border rounded-xl">
              <span className="font-bold text-slate-900 block mb-1">Utilities</span>
              <ul className="text-[10px] text-slate-500 space-y-0.5 leading-tight font-light">
                <li>• Backup generators</li>
                <li>• Compressed air</li>
                <li>• Vacuum & water</li>
                <li>• High-power test setups</li>
              </ul>
            </div>
            <div className="p-2.5 bg-slate-50 border rounded-xl">
              <span className="font-bold text-slate-900 block mb-1">Capabilities</span>
              <ul className="text-[10px] text-slate-500 space-y-0.5 leading-tight font-light">
                <li>• PCBA placement</li>
                <li>• Mechanical assembly</li>
                <li>• Product testing</li>
                <li>• System integration</li>
              </ul>
            </div>
            <div className="p-2.5 bg-slate-50 border rounded-xl">
              <span className="font-bold text-slate-900 block mb-1">Test Setup</span>
              <ul className="text-[10px] text-slate-500 space-y-0.5 leading-tight font-light">
                <li>• Four (4) SMT lines</li>
                <li>• Automatic Optical (AOI)</li>
                <li>• X-Ray chambers</li>
                <li>• Real-time internet test</li>
              </ul>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 24,
      section: "U.S. Market growth",
      title: "U.S. as a Key Growth Enabler",
      subtitle: "Unlocking structural opportunities in North American markets",
      category: "STRATEGIC FOUNDATION",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-3.5 my-auto text-xs">
            <div>
              <strong className="text-blue-900 block">Why the U.S. Market Matters:</strong>
              <p className="text-[11px] text-slate-500 font-light mt-0.5 leading-relaxed">
                Largest EMS market globally (~$90B), with growing onshoring trends and strong demand for certified, high-reliability manufacturing.
              </p>
            </div>
            <div>
              <strong className="text-blue-900 block">SVI's Core Opportunity:</strong>
              <p className="text-[11px] text-slate-500 font-light mt-0.5 leading-relaxed">
                SVI is well-positioned with deep global experience, solid financial backing, and an engineering-led approach matching strict US certification metrics.
              </p>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 25,
      section: "U.S. Cert Timeline",
      title: "SVI USA Certification Timeline",
      subtitle: "Strategic progression roadmap of site certifications in 2026",
      category: "COMPLIANCE & QUALITY",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="grid grid-cols-5 gap-1.5 my-auto text-center text-xs">
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900 bg-blue-100 text-[10px] rounded mb-1">Certified</span>
              <span className="text-[9px] text-slate-700 font-bold block">ISO 9001</span>
              <span className="text-[8px] text-slate-400 font-light block">Certify complete</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900 bg-blue-100 text-[10px] rounded mb-1">Q1'26</span>
              <span className="text-[9px] text-slate-700 font-bold block">ISO 13485</span>
              <span className="text-[8px] text-slate-400 font-light block">Requirement trg.</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900 bg-blue-100 text-[10px] rounded mb-1">Q2'26</span>
              <span className="text-[9px] text-slate-700 font-bold block">ISO 14001</span>
              <span className="text-[8px] text-slate-400 font-light block">Internal audits</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900 bg-blue-100 text-[10px] rounded mb-1">Q3'26</span>
              <span className="text-[9px] text-slate-700 font-bold block">Stage 1</span>
              <span className="text-[8px] text-slate-400 font-light block">Stage 1 audit</span>
            </div>
            <div className="p-2 bg-slate-50 border rounded-lg">
              <span className="block font-bold text-blue-900 bg-blue-100 text-[10px] rounded mb-1">Q4'26</span>
              <span className="text-[9px] text-slate-700 font-bold block">Certification</span>
              <span className="text-[8px] text-slate-400 font-light block">Full compliance</span>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 26,
      section: "Section Header",
      title: "Sales & Support Offices",
      subtitle: "Overview of global commercial liaison divisions",
      category: "SECTION DIVIDER",
      content: (
        <div className="flex flex-col items-center justify-center text-center h-full bg-slate-900 text-white p-8">
          <Globe className="w-16 h-16 text-teal-400 mb-4 animate-pulse" />
          <span className="text-xs font-mono text-teal-300 uppercase tracking-widest">CHAPTER 03</span>
          <h2 className="text-3xl font-bold mt-1 text-white">Sales & Support Offices</h2>
          <div className="h-[2px] w-16 bg-red-500 mt-3 mb-2" />
          <p className="text-slate-400 text-xs max-w-sm font-light">
            Providing direct regional assistance, localized account planning, and active engineering compliance support.
          </p>
        </div>
      )
    },
    {
      pageNum: 27,
      section: "Sales Offices",
      title: "Sales & Support Offices",
      subtitle: "Coordinating commercial activities across 7 global strategic departments",
      category: "GLOBAL REACH",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="grid grid-cols-4 gap-3 my-auto text-center text-xs">
            {["Thailand", "China", "Japan", "Denmark", "Germany", "Austria", "U.S.A."].map((c, i) => (
              <div key={i} className="p-2 bg-slate-50 border rounded-xl font-bold text-blue-950 flex flex-col justify-center">
                <span>{c}</span>
                <span className="text-[8px] font-mono text-slate-400 font-light block mt-0.5">Sales Support</span>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-3 gap-2 border-t border-slate-100 pt-3 text-[9px] text-slate-500">
            <div>
              <strong>Personalized:</strong> Direct local client communication.
            </div>
            <div>
              <strong>Speed:</strong> Accelerated issue resolution and zero lag.
            </div>
            <div>
              <strong>Adapatation:</strong> Expanding and localizing SVI offerings.
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 28,
      section: "Section Header",
      title: "Advanced Manufacturing",
      subtitle: "Digital automation and smart factory setups",
      category: "SECTION DIVIDER",
      content: (
        <div className="flex flex-col items-center justify-center text-center h-full bg-slate-900 text-white p-8">
          <Zap className="w-16 h-16 text-indigo-400 mb-4 animate-pulse" />
          <span className="text-xs font-mono text-indigo-300 uppercase tracking-widest">CHAPTER 04</span>
          <h2 className="text-3xl font-bold mt-1 text-white">Advanced Manufacturing</h2>
          <div className="h-[2px] w-16 bg-blue-500 mt-3 mb-2" />
          <p className="text-slate-400 text-xs max-w-sm font-light">
            Fully integrated assembly lines, test software developments, and robotic warehousing grids.
          </p>
        </div>
      )
    },
    {
      pageNum: 29,
      section: "Automation",
      title: "Fully Automated Lines",
      subtitle: "High-volume precision assembly optimizing output metrics",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-3 my-auto">
            <div className="p-3 bg-slate-50 rounded-xl border flex items-center justify-between">
              <div>
                <span className="font-bold text-blue-950 block text-xs">High Volume Capacity</span>
                <p className="text-[10px] text-slate-500 mt-0.5 leading-tight font-light">
                  Configured target output of <strong>600K+ complete units</strong> per single month.
                </p>
              </div>
              <span className="text-xs font-mono font-bold bg-blue-100 text-blue-800 px-2 py-1 rounded">600K+ / Month</span>
            </div>
            <div className="p-3 bg-slate-50 rounded-xl border">
              <span className="font-bold text-blue-950 block text-xs">Process Flow Integration</span>
              <p className="text-[10px] text-slate-500 mt-0.5 leading-relaxed font-light">
                Auto PCBA placement &rarr; Auto Front assembly &rarr; Auto Battery injection &rarr; Final Automated Box Build.
              </p>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 30,
      section: "Test Development",
      title: "Test Development",
      subtitle: "Proprietary software engineering and testing setups",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-3.5 my-auto text-xs">
            <p className="text-slate-600 font-light leading-relaxed">
              SVI provides advanced test development across all digital factories, using diverse tools to prevent and detect component defects. Our custom-designed testing strategies cut risk, pipeline time, and cost to streamline high-volume production.
            </p>
            <div className="grid grid-cols-2 gap-2 text-center">
              <div className="p-2 bg-slate-50 rounded-lg font-bold text-blue-950">In-Circuit Testing (ICT)</div>
              <div className="p-2 bg-slate-50 rounded-lg font-bold text-blue-950">Functional Testing (FCT)</div>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 31,
      section: "Smart Warehouse",
      title: "Automated Warehouse",
      subtitle: "Robotic warehouse management and digital component tracking",
      category: "MANUFACTURING FACILITIES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="space-y-3 my-auto">
            <p className="text-xs text-slate-600 font-light leading-relaxed">
              SVI’s automated warehouse uses smart robotics, real-time tracking, and intelligent handling to streamline logistics, reduce manual labor, speed up fulfillment, and ensure reliable supply chain performance.
            </p>
            <div className="grid grid-cols-3 gap-2 text-center text-[10px] font-mono font-bold text-slate-700">
              <div className="p-2 bg-slate-50 border rounded-lg">AGVs & Robotics</div>
              <div className="p-2 bg-slate-50 border rounded-lg">RFID Component Track</div>
              <div className="p-2 bg-slate-50 border rounded-lg">Zero Manual Errors</div>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 32,
      section: "Section Header",
      title: "Key Takeaways About Us",
      subtitle: "Summarizing primary strategic partnership parameters",
      category: "SECTION DIVIDER",
      content: (
        <div className="flex flex-col items-center justify-center text-center h-full bg-slate-900 text-white p-8">
          <Award className="w-16 h-16 text-amber-400 mb-4 animate-pulse" />
          <span className="text-xs font-mono text-amber-300 uppercase tracking-widest">CHAPTER 05</span>
          <h2 className="text-3xl font-bold mt-1 text-white">Key Takeaways About Us</h2>
          <div className="h-[2px] w-16 bg-red-500 mt-3 mb-2" />
          <p className="text-slate-400 text-xs max-w-sm font-light">
            Core strengths, blue-chip client bases, and competitive benefits summary.
          </p>
        </div>
      )
    },
    {
      pageNum: 33,
      section: "Strategic Takeaways",
      title: "Key Takeaways & Core Strengths",
      subtitle: "Solidifying our value as a reliable global manufacturing partner",
      category: "PARTNERSHIP VALUES",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 h-full p-4 text-slate-800">
          <div className="bg-slate-50 border p-3 rounded-xl flex flex-col justify-between">
            <div>
              <span className="text-xs font-mono font-bold text-blue-900 block">KEY BENEFITS</span>
              <p className="text-[10px] text-slate-500 mt-1 font-light leading-relaxed">
                Competitive pricing structures, strict compliance metrics, responsive customer accounts, and line agility.
              </p>
            </div>
          </div>
          <div className="bg-slate-50 border p-3 rounded-xl flex flex-col justify-between">
            <div>
              <span className="text-xs font-mono font-bold text-red-500 block">CUSTOMER BASE</span>
              <p className="text-[10px] text-slate-500 mt-1 font-light leading-relaxed">
                Market leaders in Europe, Americas, and Asia. Specializing in high-complexity safety critical sectors.
              </p>
            </div>
          </div>
          <div className="bg-slate-50 border p-3 rounded-xl flex flex-col justify-between">
            <div>
              <span className="text-xs font-mono font-bold text-teal-600 block">CORE STRENGTHS</span>
              <p className="text-[10px] text-slate-500 mt-1 font-light leading-relaxed">
                Fully integrated vertical support in sheet metal, plastic injection, customized cable harnesses, and full Box-Build capability.
              </p>
            </div>
          </div>
        </div>
      )
    },
    {
      pageNum: 34,
      section: "ESG Strategy",
      title: "Global ESG Strategy for SVI 2026",
      subtitle: "Committed to deep Environmental, Social, and Governance compliance",
      category: "ESG COMMITMENT",
      content: (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 h-full p-4 text-slate-800">
          <div className="p-3.5 rounded-xl border border-sky-100 bg-sky-50/20">
            <span className="px-2 py-0.5 rounded text-[8px] font-mono font-bold uppercase bg-sky-100 text-sky-600">Environment</span>
            <h5 className="font-bold text-blue-950 text-xs mt-2 mb-1">Clean Plants</h5>
            <ul className="text-[9px] text-slate-500 space-y-0.5 font-light leading-none">
              <li>• Fossil-free active energy sourcing</li>
              <li>• Strict GHG emissions drop limits</li>
              <li>• Certified Zero Waste program</li>
            </ul>
          </div>
          <div className="p-3.5 rounded-xl border border-orange-100 bg-orange-50/20">
            <span className="px-2 py-0.5 rounded text-[8px] font-mono font-bold uppercase bg-orange-100 text-orange-600">Social</span>
            <h5 className="font-bold text-blue-950 text-xs mt-2 mb-1">Safety & Core Care</h5>
            <ul className="text-[9px] text-slate-500 space-y-0.5 font-light leading-none">
              <li>• Occupational Health & safety</li>
              <li>• Human Rights active audits</li>
              <li>• Broad community sustainability</li>
            </ul>
          </div>
          <div className="p-3.5 rounded-xl border border-indigo-100 bg-indigo-50/20">
            <span className="px-2 py-0.5 rounded text-[8px] font-mono font-bold uppercase bg-indigo-100 text-indigo-600">Governance</span>
            <h5 className="font-bold text-blue-950 text-xs mt-2 mb-1">Strict Ethics</h5>
            <ul className="text-[9px] text-slate-500 space-y-0.5 font-light leading-none">
              <li>• Code of conduct & anti-corruption</li>
              <li>• Transparent ESG report indices</li>
              <li>• Comprehensive risk mitigations</li>
            </ul>
          </div>
        </div>
      )
    },
    {
      pageNum: 35,
      section: "Section Header",
      title: "SVI Closing Pledge",
      subtitle: "Our promise drives us, our people define us, and our customers inspire us",
      category: "SECTION DIVIDER",
      content: (
        <div className="flex flex-col items-center justify-center text-center h-full bg-slate-900 text-white p-8">
          <Heart className="w-16 h-16 text-red-500 mb-4 animate-pulse fill-red-500" />
          <h2 className="text-2xl font-bold mt-1 text-white leading-tight">
            "Our promise drives us, our people define us, and our customers inspire us."
          </h2>
          <div className="h-[2px] w-16 bg-blue-500 mt-4 mb-2" />
          <p className="text-slate-400 text-xs max-w-md font-light">
            Join us as we push boundaries and turn vision into reality &mdash; together, we make a difference.
          </p>
        </div>
      )
    },
    {
      pageNum: 36,
      section: "Strategic Thank you",
      title: "Thank you!",
      subtitle: "Scanning details to learn more about SVI Public Co Ltd",
      category: "PARTNERSHIP VALUES",
      content: (
        <div className="flex flex-col justify-between h-full p-6 text-slate-800">
          <div className="flex flex-col items-center justify-center text-center my-auto space-y-2">
            <Trophy className="w-12 h-12 text-amber-500 animate-bounce" />
            <h3 className="text-2xl font-bold text-blue-900 leading-none">Thank you!</h3>
            <p className="text-slate-500 text-xs font-light">Superior Service, Highest Quality</p>
            <div className="flex items-center space-x-4 pt-2">
              <div className="p-1.5 bg-slate-100 rounded-lg text-[10px] font-mono text-slate-600">Scan QR - SVI LinkedIn</div>
              <div className="p-1.5 bg-slate-100 rounded-lg text-[10px] font-mono text-slate-600">Scan QR - SVI Website</div>
            </div>
          </div>
          <div className="text-[8px] text-slate-400 font-sans leading-tight border-t border-slate-100 pt-2">
            Disclosures: This presentation is for informational purposes only matching guidelines of the Securities Exchange of Thailand.
          </div>
        </div>
      )
    }
  ];

  // Sync scroll to update activePage state in PDF view
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    if (viewMode !== "pdf") return;
    const container = e.currentTarget;
    const scrollTop = container.scrollTop;
    const containerHeight = container.clientHeight;

    // Detect which page is mostly visible
    let currentMaxPage = 1;
    let minDistance = 99999;

    for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
      const el = pageRefs.current[pageNum];
      if (el) {
        const offsetTop = el.offsetTop - container.offsetTop;
        const distance = Math.abs(offsetTop - scrollTop);
        if (distance < minDistance) {
          minDistance = distance;
          currentMaxPage = pageNum;
        }
      }
    }
    setActivePage(currentMaxPage);
  };

  const scrollToPage = (pageNum: number) => {
    setActivePage(pageNum);
    if (viewMode === "pdf") {
      const el = pageRefs.current[pageNum];
      if (el) {
        el.scrollIntoView({ behavior: "smooth", block: "start" });
      }
    }
  };

  const handleZoomIn = () => setZoom((prev) => Math.min(prev + 10, 160));
  const handleZoomOut = () => setZoom((prev) => Math.max(prev - 10, 50));
  const handleZoomReset = () => setZoom(100);

  // Handle slide prev/next for presentation mode
  const handlePrevSlide = () => {
    if (activePage > 1) {
      scrollToPage(activePage - 1);
    } else {
      scrollToPage(totalPages);
    }
  };

  const handleNextSlide = () => {
    if (activePage < totalPages) {
      scrollToPage(activePage + 1);
    } else {
      scrollToPage(1);
    }
  };

  return (
    <div className="space-y-6 py-4 animate-fade-in font-sans">
      {/* Dynamic Header Block with presentation options */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center border-b border-slate-200 pb-5 gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-950 tracking-tight flex items-center space-x-2">
            <span className="p-2 bg-red-50 text-red-600 rounded-xl border border-red-100">
              <FileText className="w-6 h-6" />
            </span>
            <span>SVI Corporate Profile</span>
          </h1>
          <p className="text-slate-500 text-sm font-light mt-1.5">
            Interactive, high-fidelity PDF Document Reader showing SVI's official global EMS profile.
          </p>
        </div>
      </div>

      {/* PDF Viewer Interface wrapper */}
      <div className="bg-slate-100 border border-slate-300 rounded-2xl overflow-hidden shadow-xl flex flex-col min-h-[620px] max-h-[85vh] relative">
        
        {/* PDF Reader Top Toolbar (Mimics Adobe/Chrome PDF Reader toolbar) */}
        <div className="bg-slate-800 text-white px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 select-none border-b border-slate-950 z-20 shadow-md">
          {/* Left tools: Document Title */}
          <div className="flex items-center space-x-3 min-w-0">
            <div className="p-1.5 rounded-lg border border-slate-700 bg-slate-900 text-slate-400 shrink-0">
              <FileText className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <span className="text-xs font-bold truncate block text-slate-100">
                {customPdf
                  ? customPdf.name
                  : "SVI_Company_Profile_Complete_2026.pdf"}
              </span>
              <span className="text-[9px] text-slate-400 font-mono block">
                {customPdf
                  ? `User Loaded PDF // ${(customPdf.size / (1024 * 1024)).toFixed(2)} MB`
                  : "Approved // Official Release // 4.8 MB"}
              </span>
            </div>
          </div>

          {/* Middle tools: Engine Badge */}
          <div className="flex items-center space-x-4 shrink-0 text-slate-200">
            <div className="text-[10px] bg-slate-900/50 px-2.5 py-1.5 rounded-lg border border-slate-700 font-mono text-blue-400 font-bold flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-blue-400 animate-pulse"></span>
              <span>NATIVE HIGH-FIDELITY BROWSER ENGINE</span>
            </div>
          </div>

          {/* Right tools: Actions, Print, Download, Upload/Remove Custom PDF */}
          <div className="flex items-center space-x-2 shrink-0">
            {customPdf ? (
              <button
                onClick={handleRemovePdf}
                className="p-1.5 rounded-lg bg-red-950/40 hover:bg-red-600/20 text-red-400 hover:text-red-200 border border-red-900/50 transition-colors"
                title="Remove Custom PDF"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            ) : (
              <label className="p-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 border border-slate-600 transition-colors text-slate-200 hover:text-white cursor-pointer" title="Upload custom SVI PDF Presentation file">
                <Upload className="w-4 h-4" />
                <input type="file" accept=".pdf" onChange={handleFileChange} className="hidden" />
              </label>
            )}

            <button
              id="pdf-action-print"
              onClick={() => {
                if (customPdfUrl) {
                  const win = window.open(customPdfUrl);
                  if (win) win.print();
                } else {
                  alert("Please upload a PDF file to print.");
                }
              }}
              className="p-1.5 rounded bg-slate-700 hover:bg-slate-600 transition-colors text-slate-200 hover:text-white"
              title="Print Profile Document"
            >
              <Printer className="w-4 h-4" />
            </button>

            {customPdfUrl ? (
              <a
                href={customPdfUrl}
                download={customPdf?.name || "SVI_Company_Profile.pdf"}
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-lg shadow transition-all shrink-0"
                title="Download Uploaded PDF"
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Download PDF</span>
              </a>
            ) : (
              <button
                onClick={() => {
                  alert("Please upload a PDF file to download.");
                }}
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-700 text-slate-400 text-xs font-bold rounded-lg cursor-not-allowed shrink-0"
                title="Download PDF"
                disabled
              >
                <Download className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Download PDF</span>
              </button>
            )}
          </div>
        </div>

        {/* Content Body: Sidebar + Main Viewer canvas */}
        <div className="flex-1 flex overflow-hidden bg-slate-600 relative">
          
          {/* Main Document Reader display view */}
          {customPdfUrl ? (
            <div className="flex-1 flex flex-col bg-slate-800 p-2 relative h-full min-h-[600px]">
              {/* Embed container */}
              <div className="flex-grow w-full h-full rounded-xl overflow-hidden shadow-inner border border-slate-900 bg-slate-900 flex flex-col">
                <iframe
                  src={`${customPdfUrl}#toolbar=1`}
                  className="w-full h-full flex-grow border-0 bg-white"
                  title={customPdf?.name || "Uploaded PDF"}
                  style={{ minHeight: "650px", height: "100%" }}
                />
              </div>
              
              {/* Embedded viewer note/troubleshooting helper */}
              <div className="flex items-center justify-between px-3 py-2 bg-slate-900/60 border-t border-slate-700/50 text-[11px] text-slate-300">
                <div className="flex items-center space-x-1.5 font-sans">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span>Exact SVI Corporate Profile file loaded.</span>
                </div>
                <a
                  href={customPdfUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="text-indigo-400 hover:text-indigo-300 font-bold transition-all underline"
                >
                  Open in new tab ↗
                </a>
              </div>
            </div>
          ) : (
            /* Drag-and-drop Dropzone Container */
            <div
              onDragOver={handleDragOver}
              onDragLeave={handleDragLeave}
              onDrop={handleDrop}
              className={`flex-1 flex flex-col items-center justify-center p-8 text-center transition-all duration-300 min-h-[550px] ${
                isDragging
                  ? "bg-indigo-50/70 border-2 border-dashed border-indigo-500 ring-4 ring-indigo-500/10"
                  : "bg-slate-50 border-2 border-dashed border-slate-300 hover:bg-slate-100/50"
              }`}
            >
              <div className="max-w-md space-y-5">
                <div className={`mx-auto w-16 h-16 rounded-2xl flex items-center justify-center shadow-md transition-all duration-300 ${
                  isDragging ? "bg-indigo-600 text-white scale-110" : "bg-white text-slate-400 border border-slate-200"
                }`}>
                  <Upload className="w-8 h-8 animate-bounce" />
                </div>
                
                <div className="space-y-2">
                  <h3 className="text-lg font-bold text-slate-900 font-sans">
                    {isDragging ? "Drop your PDF here!" : "Input SVI Corporate Profile PDF"}
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed font-light">
                    Drag and drop the exact **SVI_Company_Profile.pdf** file here, or select it from your computer to load the native PDF viewer. We'll store it securely in your local browser cache.
                  </p>
                </div>

                <div>
                  <label className="inline-flex items-center space-x-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl shadow-md cursor-pointer transition-all active:scale-95 border border-slate-950">
                    <Upload className="w-4 h-4" />
                    <span>Choose PDF File</span>
                    <input
                      type="file"
                      accept=".pdf"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                </div>

                <div className="text-[10px] font-mono text-slate-400 border-t border-slate-200/50 pt-3">
                  SECURE OFFLINE PROCESSING // POWERED BY BROWSER INDEXEDDB // NO DATA LEAVES YOUR DEVICE
                </div>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
}
