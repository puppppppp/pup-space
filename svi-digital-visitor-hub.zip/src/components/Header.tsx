import React, { useState } from "react";
import { Cpu, ShieldCheck, Wifi, Calendar, BookOpen, Layers, Menu, X, Settings, FileText } from "lucide-react";
import { Visit } from "../types";

interface HeaderProps {
  currentView: string;
  onNavigate: (view: string) => void;
  activeVisit: Visit;
  isAdmin: boolean;
  onToggleAdmin: () => void;
}

export default function Header({
  currentView,
  onNavigate,
  activeVisit,
  isAdmin,
  onToggleAdmin,
}: HeaderProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: "home", label: "Welcome", icon: BookOpen },
    { id: "agenda", label: "Today's Agenda", icon: Calendar },
    { id: "overview", label: "Company Profile", icon: FileText },
    { id: "tour", label: "Factory Tour", icon: Layers },
    { id: "quality", label: "Quality & Certs", icon: ShieldCheck },
    { id: "wifi", label: "Wi-Fi Portal", icon: Wifi },
  ];

  const handleNavClick = (viewId: string) => {
    onNavigate(viewId);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-white border-b border-slate-200 shadow-sm transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* SVI Corporate Branding */}
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2.5 cursor-pointer" onClick={() => handleNavClick("home")}>
              <div className="w-9 h-9 flex items-center justify-center shrink-0">
                <svg className="w-full h-full" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                  {/* Globe Wireframe */}
                  <circle cx="50" cy="30" r="22" stroke="#E11B22" strokeWidth="4.5" />
                  <line x1="50" y1="8" x2="50" y2="52" stroke="#E11B22" strokeWidth="4.5" />
                  <line x1="28" y1="30" x2="72" y2="30" stroke="#E11B22" strokeWidth="4.5" />
                  <path d="M 50 8 A 12 22 0 0 0 50 52" stroke="#E11B22" strokeWidth="4.5" fill="none" />
                  <path d="M 50 8 A 12 22 0 0 1 50 52" stroke="#E11B22" strokeWidth="4.5" fill="none" />
                  <path d="M 29.5 22 A 22 10 0 0 1 70.5 22" stroke="#E11B22" strokeWidth="4.5" fill="none" />
                  <path d="M 29.5 38 A 22 10 0 0 0 70.5 38" stroke="#E11B22" strokeWidth="4.5" fill="none" />
                  
                  {/* SVI Text */}
                  <text
                    x="50"
                    y="92"
                    textAnchor="middle"
                    fill="#004F9F"
                    fontSize="38"
                    fontWeight="900"
                    fontFamily="Georgia, 'Times New Roman', Times, serif"
                    letterSpacing="0.5"
                  >
                    SVI
                  </text>
                </svg>
              </div>
              <span className="font-sans font-bold text-lg tracking-tight text-slate-900">
                SVI <span className="text-slate-400 font-medium">DIGITAL</span>
              </span>
            </div>

            <div className="hidden lg:block h-4 w-[1px] bg-slate-200"></div>

            {/* Desktop Navigation Link-Style */}
            <nav className="hidden lg:flex items-center space-x-6">
              {navItems.map((item) => {
                const isActive = currentView === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-${item.id}`}
                    onClick={() => handleNavClick(item.id)}
                    className={`text-sm font-medium transition-colors duration-200 relative py-1 ${
                      isActive
                        ? "text-slate-900 after:absolute after:bottom-[-20px] after:left-0 after:right-0 after:h-[2px] after:bg-slate-900"
                        : "text-slate-500 hover:text-slate-900"
                    }`}
                  >
                    <span>{item.label}</span>
                  </button>
                );
              })}

              <div className="h-4 w-[1px] bg-slate-200"></div>

              {/* Admin Toggle Link-Style */}
              <button
                id="header-admin-toggle"
                onClick={onToggleAdmin}
                className={`text-sm font-medium transition-colors duration-200 ${
                  isAdmin ? "text-indigo-600" : "text-slate-500 hover:text-indigo-600"
                }`}
              >
                <span>{isAdmin ? "Exit Admin" : "Admin Panel"}</span>
              </button>
            </nav>
          </div>

          {/* Right Section: Meeting Room / Corporate Badge */}
          <div className="flex items-center space-x-4">
            <div className="hidden md:flex flex-col items-end text-right">
              <span className="text-[10px] font-semibold text-indigo-600 uppercase tracking-widest leading-none mb-1">
                Meeting Room
              </span>
              <span className="text-sm font-bold text-slate-800 leading-none">
                {activeVisit.meetingRoom || "Executive Suite A"}
              </span>
            </div>

            {activeVisit.customerLogo ? (
              <div className="hidden md:flex w-10 h-10 rounded-full bg-slate-100 border border-slate-200 items-center justify-center overflow-hidden shrink-0 shadow-sm">
                <img
                  src={activeVisit.customerLogo}
                  alt={activeVisit.customerName}
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = "none";
                  }}
                />
              </div>
            ) : (
              <div className="hidden md:flex w-10 h-10 rounded-full bg-slate-100 border border-slate-200 items-center justify-center overflow-hidden shrink-0">
                <span className="text-xs font-bold text-slate-400">
                  {activeVisit.customerName.slice(0, 2).toUpperCase()}
                </span>
              </div>
            )}

            {/* Mobile Actions */}
            <div className="flex items-center space-x-2 lg:hidden">
              <button
                id="mobile-admin-toggle"
                onClick={onToggleAdmin}
                className={`p-1.5 rounded-lg border transition-all ${
                  isAdmin
                    ? "bg-slate-900 border-slate-900 text-white"
                    : "bg-white border-slate-200 text-slate-600 hover:bg-slate-50"
                }`}
                title="Admin Panel"
              >
                <Settings className="w-5 h-5" />
              </button>

              <button
                id="mobile-hamburger"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="p-1.5 rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-50"
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-t border-slate-200 animate-fade-in shadow-lg">
          <div className="px-4 py-3 space-y-1">
            {/* Visiting Info for Mobile */}
            <div className="flex items-center justify-between bg-indigo-50/50 p-2.5 rounded-lg mb-3 border border-indigo-100/50">
              <span className="text-xs font-mono font-semibold text-indigo-700">Visiting Guest</span>
              <div className="flex items-center space-x-1.5">
                <span className="text-xs font-sans font-bold text-slate-800">{activeVisit.customerName}</span>
                {activeVisit.customerLogo && (
                  <img
                    src={activeVisit.customerLogo}
                    alt={activeVisit.customerName}
                    className="w-4.5 h-4.5 rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                )}
              </div>
            </div>

            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentView === item.id;
              return (
                <button
                  key={item.id}
                  id={`mobile-nav-${item.id}`}
                  onClick={() => handleNavClick(item.id)}
                  className={`flex items-center space-x-3 w-full px-4 py-3 rounded-lg text-base font-medium transition-all ${
                    isActive
                      ? "bg-slate-900 text-white"
                      : "text-slate-700 hover:bg-slate-50 hover:text-slate-900"
                  }`}
                >
                  <Icon className="w-5 h-5 text-indigo-500" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </header>
  );
}
