import React, { useState, useEffect } from "react";
import { Calendar, Clock, MapPin, CheckCircle2, ChevronRight, Play } from "lucide-react";
import { Visit, AgendaItem } from "../types";

interface AgendaViewProps {
  visit: Visit;
}

export default function AgendaView({ visit }: AgendaViewProps) {
  const [selectedItem, setSelectedItem] = useState<AgendaItem | null>(null);
  const [currentSessionId, setCurrentSessionId] = useState<string>("");

  useEffect(() => {
    if (visit.agenda && visit.agenda.length > 0) {
      // Auto-set the first one as selected for the detail panel
      setSelectedItem(visit.agenda[0]);

      // Smart session matching based on current time!
      // This is a premium addition: checking hours and highlights.
      const now = new Date();
      const currentHours = now.getHours();
      const currentMinutes = now.getMinutes();
      const currentTimeInMinutes = currentHours * 60 + currentMinutes;

      let matchedId = "";
      for (const item of visit.agenda) {
        try {
          // Parse time formats like "09:30 - 10:15" or "10:15"
          const parts = item.time.split("-");
          if (parts.length === 2) {
            const startParts = parts[0].trim().split(":");
            const endParts = parts[1].trim().split(":");
            if (startParts.length === 2 && endParts.length === 2) {
              const startMinutes = parseInt(startParts[0]) * 60 + parseInt(startParts[1]);
              const endMinutes = parseInt(endParts[0]) * 60 + parseInt(endParts[1]);
              if (currentTimeInMinutes >= startMinutes && currentTimeInMinutes <= endMinutes) {
                matchedId = item.id;
                break;
              }
            }
          }
        } catch (e) {
          // Fallback if parsing fails
        }
      }

      // If no session matches perfectly, set the first session as active
      if (matchedId) {
        setCurrentSessionId(matchedId);
        const matchedItem = visit.agenda.find((a) => a.id === matchedId);
        if (matchedItem) setSelectedItem(matchedItem);
      } else {
        // Fallback: Default highlight first session
        setCurrentSessionId(visit.agenda[0].id);
      }
    }
  }, [visit]);

  return (
    <div className="space-y-8 py-4 animate-fade-in">
      {/* Title Section */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 pb-5">
        <div>
          <h1 className="text-3xl font-sans font-bold text-slate-900 tracking-tight">Today's Agenda</h1>
          <p className="text-slate-500 text-sm font-light mt-1">
            Dynamic timeline scheduled for <span className="font-semibold text-slate-800">{visit.customerName}</span>.
          </p>
        </div>
        <div className="flex items-center space-x-3 bg-slate-100 px-4 py-2.5 rounded-xl border border-slate-200/60 shrink-0 text-sm font-mono text-slate-600">
          <Calendar className="w-4 h-4 text-indigo-600" />
          <span>{visit.visitDate}</span>
          <span className="text-slate-300">|</span>
          <MapPin className="w-4 h-4 text-emerald-600" />
          <span className="max-w-[150px] truncate">{visit.meetingRoom.split("(")[0]}</span>
        </div>
      </div>

      {/* Main Grid Content */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Timeline (Left Column) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="relative pl-6 border-l border-slate-200 space-y-8 ml-3">
            {visit.agenda?.map((item, index) => {
              const isActive = currentSessionId === item.id;
              const isSelected = selectedItem?.id === item.id;
              
              return (
                <div
                  key={item.id}
                  onClick={() => setSelectedItem(item)}
                  className={`relative cursor-pointer group transition-all duration-300 rounded-xl p-4 border ${
                    isSelected
                      ? "bg-indigo-50/75 border-indigo-200/80 shadow-sm translate-x-1"
                      : "bg-white border-transparent hover:border-slate-200 hover:bg-slate-50/50"
                  }`}
                >
                  {/* Timeline Indicator Node */}
                  <div className="absolute -left-[31px] top-7 flex items-center justify-center">
                    {isActive ? (
                      <div className="relative flex h-5 w-5">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-5 w-5 bg-emerald-500 border-2 border-white shadow-sm"></span>
                      </div>
                    ) : (
                      <div className={`h-4.5 w-4.5 rounded-full border-2 bg-white transition-colors duration-300 ${
                        index === 0
                          ? "border-indigo-600"
                          : "border-slate-300 group-hover:border-indigo-400"
                      }`} />
                    )}
                  </div>

                  {/* Header Row */}
                  <div className="flex items-center justify-between gap-2 mb-1.5">
                    <span className="flex items-center space-x-1.5 text-xs font-mono font-bold text-indigo-600 bg-indigo-50 border border-indigo-100/50 px-2 py-0.5 rounded">
                      <Clock className="w-3 h-3 shrink-0" />
                      <span>{item.time}</span>
                    </span>
                    
                    {isActive && (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[10px] font-bold font-mono uppercase bg-emerald-100 text-emerald-800 border border-emerald-200">
                        Active Now
                      </span>
                    )}
                  </div>

                  {/* Title */}
                  <h3 className={`text-base font-sans font-bold transition-colors ${
                    isSelected ? "text-indigo-900" : "text-slate-800 group-hover:text-indigo-600"
                  }`}>
                    {item.title}
                  </h3>

                  {/* Short description */}
                  <p className="text-sm text-slate-500 line-clamp-1 mt-1 font-light">
                    {item.description}
                  </p>
                </div>
              );
            }) || <div className="text-slate-400 italic">No agenda scheduled.</div>}
          </div>
        </div>

        {/* Session Detail Panel (Right Column) */}
        <div className="lg:col-span-5 sticky top-24">
          {selectedItem ? (
            <div className="bg-white border border-slate-200/80 rounded-2xl p-6 shadow-md shadow-slate-100 space-y-6 animate-fade-in">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4">
                <span className="text-xs font-semibold font-mono tracking-wide uppercase text-indigo-600">
                  Session Specifications
                </span>
                <span className="flex items-center space-x-1 text-xs font-mono text-slate-400">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>{selectedItem.time}</span>
                </span>
              </div>

              <div className="space-y-2">
                <h2 className="text-xl font-sans font-bold text-slate-900">
                  {selectedItem.title}
                </h2>
                <p className="text-slate-600 text-sm leading-relaxed font-light">
                  {selectedItem.description}
                </p>
              </div>

              {/* Enhanced Interactive Timeline Details */}
              <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 space-y-3.5">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400">Location:</span>
                  <span className="font-semibold text-slate-800">{visit.meetingRoom}</span>
                </div>
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400">Target Attendees:</span>
                  <span className="font-semibold text-slate-800">SVI Host Team & {visit.customerName} Delegation</span>
                </div>
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-400">Network Connection:</span>
                  <span className="font-semibold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-100">
                    SVI Guest Wi-Fi
                  </span>
                </div>
              </div>

              {/* Dynamic Action Button */}
              <button
                id="agenda-session-activate"
                onClick={() => setCurrentSessionId(selectedItem.id)}
                className={`w-full py-3 rounded-xl font-semibold text-sm transition-all duration-200 flex items-center justify-center space-x-2 border ${
                  currentSessionId === selectedItem.id
                    ? "bg-emerald-50 border-emerald-200 text-emerald-700 font-bold"
                    : "bg-slate-900 border-slate-900 text-white hover:bg-slate-800"
                }`}
              >
                {currentSessionId === selectedItem.id ? (
                  <>
                    <CheckCircle2 className="w-4.5 h-4.5 text-emerald-500" />
                    <span>Selected as Current Active Session</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-white text-white" />
                    <span>Set as Active Session</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="bg-slate-50 border border-dashed border-slate-200 rounded-2xl p-8 text-center text-slate-400 italic">
              Select an agenda slot on the left to inspect capabilities, logistics, and documentation.
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
