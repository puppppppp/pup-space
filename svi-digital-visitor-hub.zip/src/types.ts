export interface AgendaItem {
  id: string;
  time: string;
  title: string;
  description: string;
  isCompleted?: boolean;
}

export interface Visitor {
  id: string;
  name: string;
  title: string;
}

export interface DocumentLink {
  id: string;
  title: string;
  size: string;
  type: string;
  url: string;
}

export interface Visit {
  id: string;
  customerName: string;
  customerLogo: string; // URL or preset identifier
  visitDate: string;
  meetingRoom: string;
  wifiUser: string;
  wifiPassword?: string;
  lunchMenu: string[];
  hostTeam: string[];
  visitorList: Visitor[];
  agenda: AgendaItem[];
  documents: DocumentLink[];
  notes?: string;
  emergencyContact: {
    name: string;
    role: string;
    phone: string;
  };
}

export interface FactoryTourStep {
  id: string;
  title: string;
  subtitle: string;
  explanation: string;
  image: string;
  videoUrl?: string;
  metrics: { label: string; value: string }[];
  iconName: string;
}

export interface CertificationItem {
  id: string;
  code: string;
  title: string;
  description: string;
  industry: string;
}
