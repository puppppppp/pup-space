import React, { useState, useEffect } from "react";
import Header from "./components/Header";
import HomeView from "./components/HomeView";
import AgendaView from "./components/AgendaView";
import CompanyOverviewView from "./components/CompanyOverviewView";
import FactoryTourView from "./components/FactoryTourView";
import QualityView from "./components/QualityView";
import WifiView from "./components/WifiView";
import AdminView from "./components/AdminView";
import { DEFAULT_VISITS } from "./data";
import { Visit } from "./types";
import { ChevronRight, Layers, Heart, ShieldCheck, Mail, Phone, Calendar } from "lucide-react";

export default function App() {
  const [visits, setVisits] = useState<Visit[]>([]);
  const [activeVisitId, setActiveVisitId] = useState<string>("demovisit");
  const [currentView, setCurrentView] = useState<string>("home");
  const [isAdmin, setIsAdmin] = useState<boolean>(false);

  // Initialize and load from LocalStorage
  useEffect(() => {
    const savedVisits = localStorage.getItem("svi_visits");
    if (savedVisits) {
      try {
        const parsed = JSON.parse(savedVisits) as Visit[];
        if (parsed && parsed.length > 0) {
          setVisits(parsed);
          // Set first visit or demovisit as active
          const demoExists = parsed.find((v) => v.id === "demovisit");
          setActiveVisitId(demoExists ? "demovisit" : parsed[0].id);
        } else {
          setVisits(DEFAULT_VISITS);
          localStorage.setItem("svi_visits", JSON.stringify(DEFAULT_VISITS));
        }
      } catch (e) {
        setVisits(DEFAULT_VISITS);
      }
    } else {
      setVisits(DEFAULT_VISITS);
      localStorage.setItem("svi_visits", JSON.stringify(DEFAULT_VISITS));
    }
  }, []);

  // Sync route and Hash Routing intercepts
  useEffect(() => {
    const handleRoute = () => {
      const hash = window.location.hash;
      if (hash.startsWith("#/visit/")) {
        const visitId = hash.replace("#/visit/", "").trim();
        if (visitId) {
          // Check if it exists in current visits
          const savedVisits = localStorage.getItem("svi_visits");
          let loadedVisits: Visit[] = DEFAULT_VISITS;
          if (savedVisits) {
            try {
              loadedVisits = JSON.parse(savedVisits);
            } catch (e) {}
          }
          
          const match = loadedVisits.find((v) => v.id === visitId);
          if (match) {
            setActiveVisitId(visitId);
            setCurrentView("home");
            setIsAdmin(false);
          } else {
            console.warn(`Visit ID "${visitId}" not found. Falling back to demo.`);
            setActiveVisitId("demovisit");
            setCurrentView("home");
            setIsAdmin(false);
          }
        }
      } else if (hash === "#/admin") {
        setIsAdmin(true);
        setCurrentView("admin");
      } else if (hash === "#/home" || hash === "#/") {
        setCurrentView("home");
        setIsAdmin(false);
      }
    };

    // Listen to changes
    window.addEventListener("hashchange", handleRoute);
    
    // Call once initially if has visits
    if (visits.length > 0) {
      handleRoute();
    } else {
      // Small timeout to let visits load from storage
      setTimeout(handleRoute, 100);
    }

    return () => {
      window.removeEventListener("hashchange", handleRoute);
    };
  }, [visits]);

  // Helper to save a visit (edit or create)
  const handleSaveVisit = (newVisit: Visit) => {
    let updatedVisits = [...visits];
    const matchIdx = visits.findIndex((v) => v.id === newVisit.id);
    if (matchIdx >= 0) {
      updatedVisits[matchIdx] = newVisit;
    } else {
      updatedVisits = [...updatedVisits, newVisit];
    }
    setVisits(updatedVisits);
    localStorage.setItem("svi_visits", JSON.stringify(updatedVisits));
    setActiveVisitId(newVisit.id);
  };

  // Delete a visit
  const handleDeleteVisit = (id: string) => {
    if (id === "demovisit") return; // Keep demo
    const updated = visits.filter((v) => v.id !== id);
    setVisits(updated);
    localStorage.setItem("svi_visits", JSON.stringify(updated));
    if (activeVisitId === id) {
      setActiveVisitId("demovisit");
    }
  };

  // Get active visit configuration
  const activeVisit = visits.find((v) => v.id === activeVisitId) || visits[0] || DEFAULT_VISITS[0];

  const handleToggleAdmin = () => {
    if (isAdmin) {
      setIsAdmin(false);
      setCurrentView("home");
      window.location.hash = "#/";
    } else {
      setIsAdmin(true);
      setCurrentView("admin");
      window.location.hash = "#/admin";
    }
  };

  const handleViewNavigation = (viewId: string) => {
    if (viewId === "admin") {
      setIsAdmin(true);
    } else {
      setIsAdmin(false);
    }
    setCurrentView(viewId);
    
    // Update hash gracefully
    if (viewId === "home") {
      window.location.hash = `#/visit/${activeVisitId}`;
    } else if (viewId === "admin") {
      window.location.hash = "#/admin";
    }
  };

  // Active view routing switch
  const renderActiveView = () => {
    if (isAdmin || currentView === "admin") {
      return (
        <AdminView
          visits={visits}
          onSaveVisit={handleSaveVisit}
          onDeleteVisit={handleDeleteVisit}
          onSetActiveVisit={(id) => {
            setActiveVisitId(id);
            // Refresh preview URL hash
            window.location.hash = `#/visit/${id}`;
          }}
          activeVisitId={activeVisitId}
        />
      );
    }

    switch (currentView) {
      case "home":
        return <HomeView visit={activeVisit} onNavigate={handleViewNavigation} />;
      case "agenda":
        return <AgendaView visit={activeVisit} />;
      case "overview":
        return <CompanyOverviewView />;
      case "tour":
        return <FactoryTourView />;
      case "quality":
        return <QualityView />;
      case "wifi":
        return <WifiView visit={activeVisit} />;
      default:
        return <HomeView visit={activeVisit} onNavigate={handleViewNavigation} />;
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50/70 text-slate-800">
      {/* Sticky Premium Header */}
      <Header
        currentView={isAdmin ? "admin" : currentView}
        onNavigate={handleViewNavigation}
        activeVisit={activeVisit}
        isAdmin={isAdmin}
        onToggleAdmin={handleToggleAdmin}
      />

      {/* Main Client Canvas Area */}
      <main className="flex-grow max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="relative min-h-[500px]">
          {renderActiveView()}
        </div>
      </main>

      {/* SVI Premium Corporate Footer */}
      <footer className="bg-slate-900 text-slate-300 border-t border-slate-800 mt-16 font-sans">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="space-y-4">
              <div className="flex items-center space-x-3 mb-2">
                <div className="w-10 h-10 flex items-center justify-center shrink-0">
                  <svg className="w-full h-full" viewBox="0 0 100 100" fill="none" xmlns="http://www.w3.org/2000/svg">
                    {/* Globe Wireframe */}
                    <circle cx="50" cy="30" r="22" stroke="#E11B22" strokeWidth="4.5" />
                    <line x1="50" y1="8" x2="50" y2="52" stroke="#E11B22" strokeWidth="4.5" />
                    <line x1="28" y1="30" x2="72" y2="30" stroke="#E11B22" strokeWidth="4.5" />
                    <path d="M 50 8 A 12 22 0 0 0 50 52" stroke="#E11B22" strokeWidth="4.5" fill="none" />
                    <path d="M 50 8 A 12 22 0 0 1 50 52" stroke="#E11B22" strokeWidth="4.5" fill="none" />
                    <path d="M 29.5 22 A 22 10 0 0 1 70.5 22" stroke="#E11B22" strokeWidth="4.5" fill="none" />
                    <path d="M 29.5 38 A 22 10 0 0 0 70.5 38" stroke="#E11B22" strokeWidth="4.5" fill="none" />
                    
                    {/* SVI Text in White for dark footer background */}
                    <text
                      x="50"
                      y="92"
                      textAnchor="middle"
                      fill="#FFFFFF"
                      fontSize="38"
                      fontWeight="900"
                      fontFamily="Georgia, 'Times New Roman', Times, serif"
                      letterSpacing="0.5"
                    >
                      SVI
                    </text>
                  </svg>
                </div>
                <span className="font-bold text-lg text-white">
                  SVI <span className="text-sm text-slate-500 font-medium">Digital Hub</span>
                </span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed font-light">
                An advanced digital interface designed to replace traditional printed dossiers, delivering a seamless, responsive, and secure experience for our valued global partners visiting our assembly sites.
              </p>
              <div className="text-[10px] font-mono text-slate-500 uppercase tracking-wide">
                CONFIDENTIAL // INTERNAL SVI CLIENT SYSTEM
              </div>
            </div>

            <div className="space-y-4">
              <span className="font-bold text-sm text-white uppercase tracking-wider block">
                Corporate Core Compliance
              </span>
              <div className="space-y-2 text-xs text-slate-400">
                <div className="flex items-center space-x-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>ISO 9001, ISO 13485, IATF 16949 Certified</span>
                </div>
                <div className="flex items-center space-x-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>100% Conflict-Free Smelter Traceability</span>
                </div>
                <div className="flex items-center space-x-2">
                  <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>RoHS / REACH environmental material bounds</span>
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <span className="font-bold text-sm text-white uppercase tracking-wider block">
                SVI Logistics Assistance
              </span>
              <div className="space-y-2 text-xs text-slate-400 font-light">
                <div className="flex items-center space-x-2.5">
                  <Phone className="w-4 h-4 text-indigo-400" />
                  <span>+66 (0) 2 105 0456 (General Desk)</span>
                </div>
                <div className="flex items-center space-x-2.5">
                  <Mail className="w-4 h-4 text-indigo-400" />
                  <a href="mailto:relations@svi.co.th" className="hover:underline">
                    relations@svi.co.th
                  </a>
                </div>
                <p className="text-[10px] text-slate-500 leading-tight pt-1">
                  Pathumthani HQ Facility Address:<br />
                  141-142 Moo 5, Tiwanon Road, Bang Kadi, Pathum Thani 12000, Thailand
                </p>
              </div>
            </div>
          </div>

          <div className="mt-8 pt-8 border-t border-slate-800 flex flex-col sm:flex-row justify-between items-center text-xs text-slate-500 gap-4">
            <div>
              &copy; {new Date().getFullYear()} SVI Public Company Limited. All Rights Reserved.
            </div>
            <div className="flex items-center space-x-1.5 text-[10px] font-mono text-slate-600">
              <span>Made with dedication</span>
              <Heart className="w-3 h-3 text-red-500 fill-red-500" />
              <span>for global SVI Guest Delegations</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
